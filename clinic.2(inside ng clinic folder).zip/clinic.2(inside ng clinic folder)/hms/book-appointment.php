<?php
session_start();
date_default_timezone_set('Asia/Manila'); // Set the timezone to 'Asia/Manila'

//error_reporting(0);
include('include/config.php');
include('include/checklogin.php');
check_login();
if (!isset($_SESSION['login']) || empty($_SESSION['login'])) {
    header("Location: user-login.php");
    exit();
}
if (isset($_POST['submit'])) {
    $specilization = $_POST['Doctorspecialization'];
    $doctorid = $_POST['doctor'];
    $userid = $_SESSION['id'];
    $appdate = $_POST['appdate'];
    $time = $_POST['apptime'];
    $userstatus = 1;
    $docstatus = 1;

    // Get the current date and time
    $currentDateTime = new DateTime();
        $currentDateTime->setTimeZone(new DateTimeZone('Asia/Manila'));

    $selectedDateTime = new DateTime($appdate . ' ' . $time);

    // Check if the selected date and time are in the past
    if ($selectedDateTime < $currentDateTime) {
        // Selected date and time are in the past
        echo "<script>alert('You cant book an appointment for today!);</script>";
    } else {
        // Proceed with the appointment booking
        $query = mysqli_query($con, "INSERT INTO appointment(doctorSpecialization, doctorId, userId, appointmentDate, appointmentTime, userStatus, doctorStatus, postingDate)
                                     VALUES ('$specilization', '$doctorid', '$userid', '$appdate', '$time', '$userstatus', '$docstatus', NOW())");

        if ($query) {
            // Your appointment successfully booked
            echo "<script>alert('Your appointment successfully booked');</script>";

            // Log the action
            $action = "Booked an appointment";
            logAction($action);
        } else {
            // Error booking appointment. Please try again.
            echo "<script>alert('Error booking appointment. Please try again.');</script>";
        }
    }
}
function logAction($action)
{
    // Create a timestamp
    $timestamp = date("Y-m-d H:i:s");

    // Log the action in the auditlog table
    global $con;
    $userId = $_SESSION['id'];
    $username = $_SESSION['login'];
    $userIp = $_SERVER['REMOTE_ADDR'];

    $query = "INSERT INTO auditlog (uid, username, userip, timestamp, action) 
              VALUES ('$userId', '$username', '$userIp', '$timestamp', '$action')";
    $result = mysqli_query($con, $query);

    if (!$result) {
        echo "Error: " . mysqli_error($con);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>User | Book Appointment</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes, minimum-scale=1.0, maximum-scale=10.0">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta content="" name="description" />
    <meta content="" name="author" />
    <link rel="icon" href="umaklogos.png">   
    <link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendor/themify-icons/themify-icons.min.css">
    <link href="vendor/animate.css/animate.min.css" rel="stylesheet" media="screen">
    <link href="vendor/perfect-scrollbar/perfect-scrollbar.min.css" rel="stylesheet" media="screen">
    <link href="vendor/switchery/switchery.min.css" rel="stylesheet" media="screen">
    <link href="vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.css" rel="stylesheet" media="screen">
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="screen">
    <link href="vendor/bootstrap-datepicker/bootstrap-datepicker3.standalone.min.css" rel="stylesheet" media="screen">
    <link href="vendor/bootstrap-timepicker/bootstrap-timepicker.min.css" rel="stylesheet" media="screen">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/plugins.css">
    <link rel="stylesheet" href="assets/css/themes/theme-1.css" id="skin_color" />
    <style>
        /* Custom styles for the Book Appointment page */
        h1.mainTitle {
            color: #3498db;
            font-size: 28px;
            font-weight: bold;
            margin-bottom: 20px;
        }

        .panel.panel-white {
            border: 1px solid #ecf0f1;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .panel-heading {
            background-color: #3498db;
            color: #fff;
            border-bottom: 1px solid #2980b9;
            border-radius: 5px 5px 0 0;
        }

        .panel-body {
            padding: 20px;
        }

        .form-group label {
            font-weight: bold;
            color: #333;
        }

        .btn.btn-o.btn-primary:hover {
            background-color: blue;
            color: black;
        }

        .visible-form {
            display: block !important;
        }
    </style>

    <script>
        function getdoctor(val) {
            $.ajax({
                type: "POST",
                url: "get_doctor.php",
                data: 'specilizationid=' + val,
                success: function (data) {
                    $("#doctor").html(data);
                }
            });
        }
    </script>

    <script>
        function getfee(val) {
            $.ajax({
                type: "POST",
                url: "get_doctor.php",
                data: 'doctor=' + val,
                success: function (data) {
                    $("#fees").html(data);
                }
            });
        }
    </script>
</head>
<body>
    <div id="app">
        <?php include('include/sidebar.php'); ?>
        <div class="app-content">
            <?php include('include/header.php'); ?>
            <div class="main-content">
                <div class="wrap-content container" id="container">
                    <section id="page-title">
                        <div class="row">
                            <div class="col-sm-8">
                                <h1 class="mainTitle">User | Book Appointment</h1>
                            </div>
                        </div>
                    </section>
                    <div class="container-fluid container-fullw bg-white">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="row margin-top-30">
                                    <div class="col-lg-8 col-md-12">
                                        <div class="panel panel-white">
                                            <div class="panel-heading">
                                                <h5 class="panel-title">Book Appointment</h5>
                                            </div>
                                            <div class="panel-body">
                                                <p style="color:red;"><?php echo htmlentities($_SESSION['msg1']); ?>
                                                    <?php echo htmlentities($_SESSION['msg1'] = ""); ?></p>
                                                <form role="form" name="book" method="post">
                                                    <div class="form-group">
                                                        <label for="DoctorSpecialization">
                                                            Doctor Specialization
                                                        </label>
                                                        <select name="Doctorspecialization" class="form-control"
                                                            onChange="getdoctor(this.value);" required="required">
                                                            <option value="">Select Specialization</option>
                                                            <?php $ret = mysqli_query($con, "select * from doctorspecilization");
                                                            while ($row = mysqli_fetch_array($ret)) {
                                                            ?>
                                                                <option
                                                                    value="<?php echo htmlentities($row['specilization']); ?>">
                                                                    <?php echo htmlentities($row['specilization']); ?>
                                                                </option>
                                                            <?php } ?>
                                                        </select>
                                                    </div>
                                                    <div class="form-group">
                                                        <label for="doctor">Doctors</label>
                                                        <select name="doctor" class="form-control" id="doctor"
                                                            onChange="getfee(this.value);" required="required">
                                                            <option value="">Select Doctor</option>
                                                        </select>
                                                    </div>
                                                    <div class="form-group">
    <label for="AppointmentDate">Date</label>
    <input class="form-control datepicker" name="appdate" required="required" data-date-format="yyyy-mm-dd" min="<?php echo date('Y-m-d'); ?>">
</div>


														
                                                        <div class="form-group">
    <label for="Appointmenttime">Time</label>
    <select class="form-control" name="apptime" required="required">
        <option value="08:00">8:00 AM</option>
        <option value="08:30">8:30 AM</option>
        <option value="09:00">9:00 AM</option>
        <option value="09:30">9:30 AM</option>
        <option value="10:00">10:00 AM</option>
        <option value="10:30">10:30 AM</option>
        <option value="11:00">11:00 AM</option>
        <option value="11:30">11:30 AM</option>
        <option value="12:00">12:00 PM</option>
        <option value="12:30">12:30 PM</option>
        <option value="13:00">1:00 PM</option>
        <option value="13:30">1:30 PM</option>
        <option value="14:00">2:00 PM</option>
        <option value="14:30">2:30 PM</option>
        <option value="15:00">3:00 PM</option>
        <option value="15:30">3:30 PM</option>
        <option value="16:00">4:00 PM</option>
        <option value="16:30">4:30 PM</option>
        <option value="17:00">5:00 PM</option>
    </select>
</div>
<p id="errorMessage" style="color: red;"></p>
                                                    <button type="submit" name="submit" class="btn btn-o btn-primary">
                                                        Submit
                                                    </button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <?php include('include/setting.php');?>
    </div>
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
    <script src="vendor/modernizr/modernizr.js"></script>
    <script src="vendor/jquery-cookie/jquery.cookie.js"></script>
    <script src="vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
    <script src="vendor/switchery/switchery.min.js"></script>
    <script src="assets/js/main.js"></script>
    <script src="assets/js/form-elements.js"></script>
    <script src="vendor/maskedinput/jquery.maskedinput.min.js"></script>
    <script src="vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
    <script src="vendor/autosize/autosize.min.js"></script>
    <script src="vendor/selectFx/classie.js"></script>
    <script src="vendor/selectFx/selectFx.js"></script>
    <script src="vendor/select2/select2.min.js"></script>
    <script src="vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
    <script src="vendor/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
    
    <script>
        $('.datepicker').datepicker({
            format: 'yyyy-mm-dd',
            startDate: 'today',
        });

        $('#timepicker1').timepicker();
    </script>
    <script>
        jQuery(document).ready(function () {
            Main.init();
            FormElements.init();
        });
    </script>
<script>
$(document).ready(function () {
    // Initialize datepicker with beforeShowDay function
    $('.datepicker').datepicker({
        format: 'yyyy-mm-dd',
        startDate: 'today',
        beforeShowDay: function (date) {
            // Get day of the week (0 = Sunday, 1 = Monday, ..., 6 = Saturday)
            var day = date.getDay();

            // Disable Saturdays (day === 6) and Sundays (day === 0)
            return [day !== 0 && day !== 6, ''];
        }
    });

    // Attach change event to datepicker
    $('.datepicker').change(updateSubmitButtonState);

    function updateSubmitButtonState() {
        // Get the selected date from the datepicker
        var selectedDate = new Date($('.datepicker').val());
        var currentDate = new Date();

        // Check if the selected date is in the past
        var isPastDate = selectedDate.getTime() <= currentDate.getTime();

        // Check if the selected date is a Saturday or Sunday
        var isWeekend = selectedDate.getDay() === 0 || selectedDate.getDay() === 6;

        // Display the error message and disable/enable the submit button
        if (isPastDate || isWeekend) {
            var errorMessage = isWeekend ? "The UMak Medical and Dental Clinic is closed during Saturday and Sunday!!" : "Book an Appointment in the future dates only!!";
            $('#errorMessage').text(errorMessage);
            $('button[name="submit"]').prop('disabled', true);
        } else {
            $('#errorMessage').text('');
            $('button[name="submit"]').prop('disabled', false);
        }
    }
});
</script>
    
</body>
</html>