<?php
session_start();
error_reporting(0);
include('include/config.php');
include('include/checklogin.php');
check_login();

if (isset($_GET['id'])) {
    $appointmentId = $_GET['id'];

    // Check if the appointment exists
    $checkAppointment = mysqli_query($con, "SELECT * FROM appointment WHERE id = '$appointmentId'");
    $row = mysqli_fetch_assoc($checkAppointment);

    if ($row) {
        // Delete the appointment
        $deleteQuery = mysqli_query($con, "DELETE FROM appointment WHERE id = '$appointmentId'");

        if ($deleteQuery) {
            $_SESSION['msg'] = "Appointment deleted successfully.";
        } else {
            $_SESSION['msg'] = "Error deleting appointment. Please try again.";
        }
    } else {
        $_SESSION['msg'] = "Appointment not found.";
    }
} else {
    $_SESSION['msg'] = "Invalid request. Please try again.";
}

// Redirect back to the appointment history page
header("Location: appointment-history.php");
exit();
?>
