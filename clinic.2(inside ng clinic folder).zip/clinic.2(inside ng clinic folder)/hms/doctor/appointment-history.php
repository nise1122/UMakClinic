<?php
session_start();
error_reporting(0);
include('include/config.php');
include('include/checklogin.php');
require 'C:\xampp\htdocs\UMakClinic\vendor\autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

check_login();

if (isset($_GET['cancel'])) {
    $appointmentId = $_GET['id'];

    // Retrieve appointment details before updating the status
    $appointmentDetails = mysqli_fetch_assoc(mysqli_query($con, "SELECT * FROM appointment WHERE id = '$appointmentId'"));
    $appointmentDate = $appointmentDetails['appointmentDate'];
    $appointmentTime = $appointmentDetails['appointmentTime'];

    // Update appointment status in the database
    mysqli_query($con, "UPDATE appointment SET approvalStatus='0', userStatus='0' WHERE id ='$appointmentId'");

    if (mysqli_affected_rows($con) > 0) {
        // Send email to the patient about the cancellation
        $patientId = $appointmentDetails['userId'];
        $patientInfo = mysqli_fetch_assoc(mysqli_query($con, "SELECT email, fullName FROM users WHERE id = '$patientId'"));
        $patientEmail = $patientInfo['email'];
        $patientName = $patientInfo['fullName'];

        $subject = "Appointment Canceled";
        $message = "Your appointment on $appointmentDate at $appointmentTime has been canceled by the doctor.";
        $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'medicalanddentalc@gmail.com';
            $mail->Password = 'ukzseeeuyzjwaptz';
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
            $mail->Port = 465;

            $mail->setFrom('baracolangelica436@gmail.com');
            $mail->addAddress($patientEmail, $patientName);
            $mail->isHTML(true);
            $mail->Subject = $subject;
            $mail->Body = $message;

            $mail->send();
            $_SESSION['msg'] = "Appointment canceled. Email sent to the patient.";
        } catch (Exception $e) {
            $_SESSION['msg'] = "Error canceling appointment. Email not sent. Error: " . $mail->ErrorInfo;
        }
    } else {
        $_SESSION['msg'] = "Error canceling appointment.";
    }
}

if (isset($_POST['approve'])) {
    $appointmentId = $_POST['appointmentId'];
    $approvalStatus = $_POST['approvalStatus'];

    // Retrieve patient's email and appointment details
    $appointmentDetails = mysqli_fetch_assoc(mysqli_query($con, "SELECT userId, appointmentDate, appointmentTime FROM appointment WHERE id = '$appointmentId'"));
    $patientId = $appointmentDetails['userId'];
    $patientInfo = mysqli_fetch_assoc(mysqli_query($con, "SELECT email, fullName FROM users WHERE id = '$patientId'"));
    $patientEmail = $patientInfo['email'];
    $patientName = $patientInfo['fullName'];
    $appointmentDate = $appointmentDetails['appointmentDate'];
    $appointmentTime = $appointmentDetails['appointmentTime'];

    // Update approval status in the database
    mysqli_query($con, "UPDATE appointment SET approvalStatus = '$approvalStatus' WHERE id = '$appointmentId'");

    // Send email to the patient with appointment details
    $subject = "Appointment Approved";
    $message = "Your appointment on $appointmentDate at $appointmentTime has been approved.";
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'medicalanddentalc@gmail.com';
        $mail->Password = 'ukzseeeuyzjwaptz';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        $mail->Port = 465;

        $mail->setFrom('baracolangelica436@gmail.com');
        $mail->addAddress($patientEmail, $patientName);
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body = $message;

        $mail->send();
        $_SESSION['msg'] = "Appointment approved. Email sent to the patient.";
    } catch (Exception $e) {
        $_SESSION['msg'] = "Error approving appointment. Email not sent. Error: " . $mail->ErrorInfo;
    }
}

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <title>Doctor | Appointment History</title>
    <link rel="icon" href="umaklogos1.png">
    <link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendor/themify-icons/themify-icons.min.css">
    <link href="vendor/animate.css/animate.min.css" rel="stylesheet" media="screen">
    <link href="vendor/perfect-scrollbar/perfect-scrollbar.min.css" rel="stylesheet" media="screen">
    <link href="vendor/switchery/switchery.min.css" rel="stylesheet" media="screen">
    <link href="vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.css" rel="stylesheet" media="screen">
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="screen">
    <link href="vendor/bootstrap-datepicker/bootstrap-datepicker3.standalone.min.css" rel="stylesheet" media="screen">
    <link href="vendor/bootstrap-timepicker/bootstrap-timepicker.min.css" rel="stylesheet" media="screen">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/plugins.css">
    <link rel="stylesheet" href="assets/css/themes/theme-1.css" id="skin_color" />
</head>

<body>
    <div id="app">
        <?php include('include/sidebar.php'); ?>
        <div class="app-content">
            <?php include('include/header.php'); ?>
            <div class="main-content">
                <div class="wrap-content container" id="container">
                    <section id="page-title">
                        <div class="row">
                            <div class="col-sm-8">
                                <h1 class="mainTitle">Doctor | Appointment History</h1>
                            </div>
                        </div>
                    </section>
                    <div class="container-fluid container-fullw bg-white">
                        <div class="row">
                            <div class="col-md-12">
                                <p style="color:red;"><?php echo htmlentities($_SESSION['msg']); ?>
                                    <?php echo htmlentities($_SESSION['msg'] = ""); ?></p>
                                <table class="table table-hover" id="sample-table-1">
                                    <thead>
                                        <tr>
                                            <th class="center">#</th>
                                            <th class="hidden-xs">Patient Name</th>
                                            <th>Specialization</th>
                                            <th>Appointment Date / Time </th>
                                            <th>Appointment Creation Date </th>
                                            <th>Current Status</th>
                                            <th>Approval Status</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
    <?php
    $sql = mysqli_query($con, "select users.fullName as fname,appointment.*  from appointment join users on users.id=appointment.userId where appointment.doctorId='" . $_SESSION['id'] . "'");
    $cnt = 1;
    while ($row = mysqli_fetch_array($sql)) {
    ?>
                                             <tr>
            <td class="center"><?php echo $cnt; ?>.</td>
            <td class="hidden-xs"><?php echo $row['fname']; ?></td>
            <td><?php echo $row['doctorSpecialization']; ?></td>
            <td><?php echo $row['appointmentDate']; ?> / <?php echo $row['appointmentTime']; ?></td>
            <td><?php echo $row['postingDate']; ?></td>
            <td>
    <?php
    if ($row['userStatus'] == 1 && $row['doctorStatus'] == 1) {
        echo "Active";
    } elseif ($row['userStatus'] == 0 && $row['doctorStatus'] == 1) {
        echo "Cancel by Doctor";
    } elseif ($row['userStatus'] == 0 && $row['doctorStatus'] == 0) {
        echo "Cancel by Patient";
    } else {
        echo ""; // Add this line to handle other cases
    }
    ?>
</td>



             <td>
    <form method="post">
        <?php if ($row['approvalStatus'] != 1) { ?>
            <button type="submit" name="approve" class="btn btn-primary" id="approveBtn_<?php echo $row['id']; ?>">Approve</button>
        <?php } else { ?>
            <span class="text-success">Approved</span>
        <?php } ?>
        <input type="hidden" name="appointmentId" value="<?php echo $row['id']; ?>">
        <input type="hidden" name="approvalStatus" value="1">
    </form>
</td>

<td>
    <div class="visible-md visible-lg hidden-sm hidden-xs">
        <?php if (($row['userStatus'] == 1) && ($row['doctorStatus'] == 1)) { ?>
            <div class="dropdown">
                <button class="btn btn-primary dropdown-toggle" type="button" data-toggle="dropdown">
                    Action
                    <span class="caret"></span>
                </button>
                <ul class="dropdown-menu">
                    <li>
                        <a href="appointment-history.php?id=<?php echo $row['id'] ?>&cancel=update" onclick="return confirm('Are you sure you want to cancel this appointment ?')">
                            Cancel
                        </a>
                    </li>
                    <li>
                        <a href="add-patient.php?id=<?php echo $row['id']?>&patientName=<?php echo urlencode($row['fname']) ?>">Manage</a>
                    </li>
                    <li>
                        <?php if ($row['approvalStatus'] != 1) { ?>
                            <a href="done-appointment.php?id=<?php echo $row['id'] ?>" onclick="return confirm('Are you sure this appointment is done?')">
                                Done
                            </a>
                        <?php } else { ?>
                            <span class="text-success">Done</span>
                        <?php } ?>
                    </li>
                    <li>
                        <a href="delete-appointment.php?id=<?php echo $row['id'] ?>" onclick="return confirm('Are you sure you want to delete this appointment ?')">
                            Delete
                        </a>
                    </li>
                </ul>
            </div>
        <?php } else {
            echo ($row['approvalStatus'] == 1) ? "Done" : "Cancelled";
        } ?>
    </div>
</td>

                                            </tr>
                                        <?php
                                            $cnt = $cnt + 1;
                                        } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php include('include/setting.php'); ?>
        </div>
        <script src="vendor/jquery/jquery.min.js"></script>
        <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
        <script src="vendor/modernizr/modernizr.js"></script>
        <script src="vendor/jquery-cookie/jquery.cookie.js"></script>
        <script src="vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
        <script src="vendor/switchery/switchery.min.js"></script>
        <script src="assets/js/main.js"></script>
        <script src="assets/js/form-elements.js"></script>
        <script>
            jQuery(document).ready(function() {
                Main.init();
                FormElements.init();
            });
        </script>
        
        <script>
    $(document).ready(function() {
        // Loop through each dropdown and set the selected option based on the initial approval status
        $(".approval-status").each(function() {
            var initialApprovalStatus = $(this).closest('tr').find('.initial-approval-status').val();
            $(this).val(initialApprovalStatus);
        });

        $(".approval-status").change(function() {
            var appointmentId = $(this).data("appointment-id");
            var approvalStatus = $(this).val();

            // Make an AJAX request to update the approval status
            $.ajax({
                type: "POST",
                url: "update-approval-status.php", // Replace with the actual URL for updating approval status
                data: {
                    appointmentId: appointmentId,
                    approvalStatus: approvalStatus
                },
                success: function(response) {
                    // Handle the response if needed
                },
                error: function(error) {
                    console.error("Error updating approval status:", error);
                }
            });
        });
    });
</script>
<script>
    $(document).ready(function() {
        $(".btn-primary").click(function() {
            // Disable the button to prevent multiple clicks
            $(this).prop("disabled", true);

            // Change the button text to "Approved"
            $(this).text("Approved");
        });
    });
</script>

    </body>

</html>