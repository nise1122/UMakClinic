<!DOCTYPE html>
<html lang="en">
<head>
    <title>Your Website</title>
    <style>
        

        .main-navigation-menu li {
            margin-bottom: 10px;
        }

        .main-navigation-menu a {
            display: block;
            padding: 10px;
            color: #ecf0f1;
            text-decoration: none;
            transition: background-color 0.3s, color 0.3s;
        }

        .main-navigation-menu a:hover {
            background-color: #34495e;
            color: #ffffff;
        }

        .sub-menu {
            display: none;
            background-color: #2c3e50;
        }

        .sub-menu a {
            padding: 8px 20px;
            color: #ecf0f1;
            text-decoration: none;
            transition: background-color 0.3s, color 0.3s;
        }

        .sub-menu a:hover {
            background-color: #34495e;
            color: #ffffff;
        }

        .main-navigation-menu li:hover .sub-menu {
            display: block;
        }

        .sidebar-toggle {
            cursor: pointer;
            padding: 10px;
            text-align: center;
            background-color: #34495e;
            transition: background-color 0.3s;
        }

        .sidebar-toggle i {
            color: #ecf0f1;
        }

        .sidebar-toggle:hover {
            background-color: #2c3e50;
        }
    </style>
</head>
<body>
<div class="sidebar app-aside" id="sidebar">
    <div class="sidebar-container perfect-scrollbar">
        <nav>
            <div class="navbar-title">
                <h3>Your Website Name</h3>
            </div>
            <ul class="main-navigation-menu">
                <li>
                    <a href="dashboard.php">
                        <i class="ti-home"></i>
                        <span class="title"> Dashboard </span>
                    </a>
                </li>

                <li>
                    <a href="appointment-history.php">
                        <i class="ti-list"></i>
                        <span class="title"> Appointment History </span>
                    </a>
                </li>

                <li>
                    <a href="javascript:void(0)">
                        <i class="ti-user"></i>
                        <span class="title"> Patients </span><i class="icon-arrow"></i>
                    </a>
                    <ul class="sub-menu">
                        <li>
                            <a href="add-patient.php">
                                <span class="title"> Add Patient</span>
                            </a>
                        </li>
                        <li>
                            <a href="manage-patient.php">
                                <span class="title"> Manage Patient </span>
                            </a>
                        </li>
                    </ul>
                </li>

                <li>
                    <a href="search.php">
                        <i class="ti-search"></i>
                        <span class="title"> Search </span>
                    </a>
                </li>
            </ul>
            <!-- end: CORE FEATURES -->
        </nav>

        <!-- Add a toggle button for the collapsed state -->
        <div class="sidebar-toggle" onclick="toggleSidebar()">
            <i class="ti-angle-left"></i>
        </div>
    </div>
</div>

<script>
    // JavaScript to toggle the sidebar's collapsed state
    function toggleSidebar() {
        document.getElementById('sidebar').classList.toggle('collapsed');
    }
</script>

</body>
</html>
