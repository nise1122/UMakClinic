<?php
require __DIR__ . '/../vendor/autoload.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

if (isset($_GET['exportToExcel']) && $_GET['exportToExcel'] == 1) {
    // ... (existing code)

    // Save the spreadsheet to a file
    $filename = isset($_GET['filename']) ? $_GET['filename'] : 'patient_data_' . date('YmdHis') . '.xlsx';
    $writer = new Xlsx($spreadsheet);
    $writer->save($filename);

    // Redirect back to the form page or do other necessary actions
    header('Location: add-patient.php');
    exit();
} else {
    // Handle other cases or redirect to an error page
    header('Location: error.php');
    exit();
}
?>
