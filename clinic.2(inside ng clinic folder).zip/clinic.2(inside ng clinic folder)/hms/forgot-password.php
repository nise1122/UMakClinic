<?php
session_start();
include_once('include/config1.php');

// Include Composer autoload
require __DIR__ . '/vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

if (isset($_POST['submit'])) {
    $email = mysqli_real_escape_string($conn, $_POST['email']);

    // Check if the email exists in the users table
    $check_email = mysqli_query($conn, "SELECT email FROM users WHERE email = '$email'");
    $res = mysqli_num_rows($check_email);

    if ($res > 0) {
        // Generate a unique token for the reset link
        $token = bin2hex(random_bytes(32));

        // Insert the user's information into the password_reset table
        $insert_query = "INSERT INTO password_reset (email, token, timestamp) VALUES ('$email', '$token', NOW())";
        mysqli_query($conn, $insert_query);

        // Send the password reset link
        $subject = 'Reset Password';
        $message = 'Hello,<br><br>You are receiving this email because we received a password reset request for your account.<br><br>';
        $message .= '<a href="https://university-of-makati-medical-anddental-clinic.000webhostapp.com/hms/reset-password.php?email=' . $email . '">Reset Password</a><br><br>';
        $message .= 'If you did not request a password reset, no further action is required.';

        $mail = new PHPMailer;
        $mail->IsSMTP();
        $mail->SMTPAuth = true;
        $mail->Host = 'smtp.gmail.com';
        $mail->Port = 465;
        $mail->Username = 'medicalanddentalc@gmail.com';
        $mail->Password = 'ukzseeeuyzjwaptz';
        $mail->setFrom('umakmedicalanddentalclinic@gmail.com', 'UMak Medical and Dental Clinic');  // Replace with your email and name
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        $mail->AddAddress($email);
        $mail->Subject = $subject;
        $mail->isHTML(true);
        $mail->Body = $message;

        // Send the email
        try {
            $mail->send();
            $msg = "We have e-mailed your password reset link!";
        } catch (Exception $e) {
            $msg = "Email could not be sent. Error: {$mail->ErrorInfo}";
        }
    } else {
        $msg = "We can't find a user with that email address";
    }

    // Redirect regardless of success or failure
    header('Location: send-password.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<title>Patient Password Recovery</title>
							<meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes, minimum-scale=1.0, maximum-scale=10.0">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
		<meta content="" name="description" />
		<meta content="" name="author" />  
		<link rel="icon" href="umaklogos.png">   
		<link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
		<link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
		<link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.min.css">
		<link rel="stylesheet" href="vendor/themify-icons/themify-icons.min.css">
		<link href="vendor/animate.css/animate.min.css" rel="stylesheet" media="screen">
		<link href="vendor/perfect-scrollbar/perfect-scrollbar.min.css" rel="stylesheet" media="screen">
		<link href="vendor/switchery/switchery.min.css" rel="stylesheet" media="screen">
		<link rel="stylesheet" href="assets/css/styles.css">
		<link rel="stylesheet" href="assets/css/plugins.css">
		<link rel="stylesheet" href="assets/css/themes/theme-1.css" id="skin_color" />
	</head>
	<body class="login">
		<div class="row">
			<div class="main-login col-xs-10 col-xs-offset-1 col-sm-8 col-sm-offset-2 col-md-4 col-md-offset-4">
				<div class="logo margin-top-30">
				<a href="../index.html"><h2>Patient Password Recovery</h2></a>
				</div>

				<div class="box-login">
					<form class="form-login" method="post">
						<fieldset>
							<legend>
								Patient Password Recovery
							</legend>
							<p>
								Please enter your Email to recover your password.<br />
					
							</p>

				

							<div class="form-group">
								<span class="input-icon">
									<input type="email" class="form-control" name="email" placeholder="Registred Email" required>
									<i class="fa fa-user"></i> </span>
							</div>

							<div class="form-actions">
								
								<button type="submit" class="btn btn-primary pull-right" name="submit">
                                Send Password Reset Link <i class="fa fa-arrow-circle-right"></i>
								</button>
							</div>
                            <p class="error"><?php if(!empty($msg)){ echo $msg; } ?></p>
							<div class="new-account">
								Already have an account? 
								<a href="user-login.php">
									Log-in
								</a>
							</div>
						</fieldset>
					</form>
			
				</div>

			</div>
		</div>
		<script src="vendor/jquery/jquery.min.js"></script>
		<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
		<script src="vendor/modernizr/modernizr.js"></script>
		<script src="vendor/jquery-cookie/jquery.cookie.js"></script>
		<script src="vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
		<script src="vendor/switchery/switchery.min.js"></script>
		<script src="vendor/jquery-validation/jquery.validate.min.js"></script>
	
		<script src="assets/js/main.js"></script>

		<script src="assets/js/login.js"></script>
		<script>
			jQuery(document).ready(function() {
				Main.init();
				Login.init();
			});
		</script>
	
	</body>
	<!-- end: BODY -->
</html>