<?php
// log-endpoint.php

// Function to log the entry to a file
function logToFile($logEntry)
{
    // Set the path to your log file
    $logFile = 'logs/audit-log.txt';

    // Add a new line to the log file
    file_put_contents($logFile, $logEntry . PHP_EOL, FILE_APPEND);

    // You can customize this function based on your logging requirements
}

// Check if the log entry is provided in the POST request
if (isset($_POST['logEntry'])) {
    $logEntry = $_POST['logEntry'];

    // Log the entry
    logToFile($logEntry);

    // Respond with a success message
    echo 'Log entry received and processed successfully.';
} else {
    // Respond with an error message if log entry is not provided
    echo 'Error: Log entry not provided.';
}
?>
