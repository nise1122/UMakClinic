<?php
include_once('hms/include/config.php');
if(isset($_POST['submit']))
{
$name=$_POST['fullname'];
$email=$_POST['emailid'];
$mobileno=$_POST['mobileno'];
$dscrption=$_POST['description'];
$query=mysqli_query($con,"insert into tblcontactus(fullname,email,contactno,message) value('$name','$email','$mobileno','$dscrption')");
echo "<script>alert('Your information succesfully submitted');</script>";
echo "<script>window.location.href ='contact.php'</script>";

}
?>

<!DOCTYPE HTML>
<html lang="en">

<head>
    <title>Medical and Dental Clinic</title>
    <link rel="stylesheet" href="css/navstyle.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="icon" href="umaklogo.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css"
        integrity="sha384-wvfXpqpZZVQGK6TAh5PVlK3uPfNfexUEFpy+JcPXdA0R+5dFZtFm4nFj1cO5N2+7" crossorigin="anonymous">
    <link href='http://fonts.googleapis.com/css?family=Ropa+Sans' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="css/responsiveslides.css">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css">

    <!-- Add these lines to include jQuery and Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

    <style>
        
        .header-section {
            position: relative;
            height: 50vh;
            background-image: url('images/show4.jpg'); 
            background-size: cover;
            background-position: center;
            color: #fff;
            display: flex;
            align-items: center;
            justify-content: center;
            text-align: center;
        }

        .header-section h2 {
            font-size: 3em;
            margin-bottom: 20px;
        }

        .contact-section {
            padding: 50px 0;
        }

        .company-address {
            color: #555;
        }

        .contact-form {
            background-color: #fff;
            padding: 20px;
            border: 1px solid #ddd;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            font-weight: bold;
            margin-bottom: 5px;
            color: #333;
        }

        .form-group input,
        .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }

        .form-group input[type="submit"] {
            background-color: rgba(51, 124, 207, 0.8);
            color: #fff;
            cursor: pointer;
        }

        .form-group input[type="submit"]:hover {
            background-color: blue;
        }
    </style>

</head>

<body>

    <!-- Navigation Section -->
   <!--start-header-->
   <div class="header">
        <div class="wrap">
            <!--start-logo-->
            <nav class="navbar navbar-expand-custom navbar-mainbg fixed-top">
                <div class="logo-container">
                    <img src="logomed.png" style="max-height: 70px; margin-right: 3px;">
                    <div class="text-container">
                        <span class="navbar-brand navbar-logo clinic-name">MEDICAL AND DENTAL CLINIC</span>
                    </div>
                </div>
  

                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fas fa-bars text-black"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item">
                                <a class="nav-link" href="index.php"><i class="fas fa-home"></i>HOME</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="about.php"><i class="far fa-address-book"></i>ABOUT</a>
                            </li>
                           
                            <li class="nav-item active">
                                <a class="nav-link" href="contact.php"><i class="far fa-envelope"></i>CONTACT</a>
                            </li>
    </div>

                </nav>
				<!--end-top-nav-->
			</div>
			<!--end-header-->

    <div class="header-section">
        <div>
            <h2>Contact Us</h2>
        </div>
    </div>

    <!-- Contact Information and Form Section -->
    <div class="container contact-section">
        <div class="row">
            <!-- Contact Information on the Left -->
            <div class="col-md-6">
                <div class="company-address">
                    <h2>Contact Information</h2>
                    <p>DR. ALAN ANGELO N. RAYMUNDO</p>
                    <p>Department Head</p>
                    <p>Direct Line: 8883-1863</p>
                    <p>Cellphone Number: 0945 648 2351</p>
                    <p>Email: <span>clinic@umak.edu.ph</span></p>
                    <p>Office Location: <span>Ground Floor, Admin Building</span></p>
                </div>
            </div>
            <!-- Contact Form on the Right -->
            <div class="col-md-6">
                <div class="contact-form">
                    <h2>Contact Us</h2>
                    <form name="contactus" method="post">
                        <div class="form-group">
                            <label for="fullname">Name</label>
                            <input type="text" name="fullname" required="true" value="">
                        </div>
                        <div class="form-group">
                            <label for="emailid">University Email</label>
                            <input type="email" name="emailid" required="true" value="">
                        </div>
                        <div class="form-group">
                            <label for="mobileno">Contact Number</label>
                            <input type="text" name="mobileno" required="true" value="">
                        </div>
                        <div class="form-group">
                            <label for="description">Description</label>
                            <textarea name="description" required="true"></textarea>
                        </div>
                        <div class="form-group">
                            <input type="submit" name="submit" value="Submit">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer Section -->
    <?php include('footer1.html'); ?>

</body>

</html>
