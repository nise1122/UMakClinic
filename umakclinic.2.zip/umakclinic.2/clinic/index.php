<!DOCTYPE html>
<html lang="en">
<head>
    <title>Medical and Dental Clinic</title>
    <link href="css/navstyle.css" rel="stylesheet" type="text/css" media="all" />
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="index1.css">
    <link rel="icon" href="umaklogo.png">
    <link href='http://fonts.googleapis.com/css?family=Ropa+Sans' rel='stylesheet' type='text/css'>
    <script src="js/navbar.js"></script>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
<style>
    .announcement {
    background: linear-gradient(135deg, #001f3f, #009688, #0056b3, #003366); 
    color: white;
    text-align: center;
    padding: 5px;
    margin-top: 150px; 
    width: 50%;
    border-radius: 5px;
    left: 53%;
    transform: translateX(-50%);
    display: block;

}
.listview_1_of_3 .icon img {
max-width: 100%;
height: auto;
margin-bottom: -50px;
margin-left: 10px;
transition: transform 0.3s ease; 

}
</style>
<body>

    <!--start-header-->
    <div class="header">
        <div class="wrap">
            <!--start-logo-->
            <nav class="navbar navbar-expand-custom navbar-mainbg">
        <div class="logo-container">
        <img src="logomed.png" style="max-height: 70px; margin-right: 3px;">
            <span class="navbar-brand navbar-logo clinic-name">MEDICAL AND DENTAL CLINIC</span>
        </div>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <i class="fas fa-bars"></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item active">
                            <a class="nav-link" href="index.php"><i class="fas fa-home"></i>HOME</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="about.php"><i class="far fa-address-book"></i>ABOUT</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact.php"><i class="far fa-envelope"></i>CONTACT</a>
                        </li>
                    </ul>
                </div>
            </nav>
            <!--end-top-nav-->
        </div>
        <!--end-header-->
        <div class="parallax">
        <div class="announcement">
    <p>Welcome to UMak Medical and Dental Clinic Virtual Campus! Ready to book your appointment? <a href="hms/book-appointment.php">Click here</a>.</p>
</div>

    </div>

    <div class="clear"> 
		    <div class="content-grids">
		    	<div class="wrap">
		    	<div class="section group">
                               <!-- Add this HTML to your existing code, adjust class names as needed -->
                               <div class="listview_1_of_3">
                               <a href="hms/doctor/" class="icon">
        <div class="image-container">
            <img src="images/patient.gif" alt="Doctors Login">
            <div class="texts">
                <h3>DOCTORS LOGIN</h3>
            </div>
        </div>
    </a>

    <a href="hms/admin" class="icon">
        <div class="image-container">
            <img src="images/admin.gif" alt="Admin Login">
            <div class="texts">
                <h3>ADMIN LOGIN</h3>
            </div>
        </div>
    </a>
</div>


        <!--chatbot-->
        <button id="chatbot-icon" onclick="toggleChatbox()"></button>

<section id="chat-section12">
    <div id="chat-box"></div>

    <div class="choices">
        <button class="choice" onclick="sendChoice('Clinic Hours')">Clinic Hours</button>
        <button class="choice" onclick="sendChoice('Location')">Location</button>
        <button class="choice" onclick="sendChoice('Payment')">Payment</button>
        <button class="choice" onclick="sendChoice('Services')">Services</button>
        <button class="choice" onclick="sendChoice('Can patient outside UMak book an appointment here?')">Can patient outside UMak book an appointment here?</button>
        <button class="choice" onclick="sendChoice('How to Book an Appointment')">How to Book an Appointment</button>
    </div>

    <input type="text" id="user-input" placeholder="Type your message...">
    <button id="send-button" onclick="sendMessage()">Send</button>
</section>


        <!--About-->
        <div class="about-container">
            <div class="wrap">
                <h2>ABOUT</h2>
                <p class="clinic-info">
                    <span class="clinic-name2">MEDICAL AND DENTAL CLINIC</span>
                </p>
                <P> <span class="university1">UNIVERSITY OF MAKATI</span> </P>
                <p>
                    The Medical and Dental Clinic intends to provide basic healthcare for students and/or refer them to the specialist/primary health center if necessary. It provides first aid and triage for illnesses and injuries, direct services to students with special needs, and health counseling and education to students, staff, and parents.
                </p>
               
            </div>
        </div>
    </div>
    <div class="parallax">
            <!-- Mission and Vision Section -->
            <section id="mission-vision" class="mission-vision-section">
                <div class="mission-container">
                    <div class="mission-content">
                        <h2>MISSION</h2>
                        <p>With its commitment in service, the clinic shall provide the medical and dental needs of the University of Makati community by doing preventive medicine and treatment of illness.</p>
                    </div>
                </div>

                <div class="vision-container">
                    <div class="vision-content">
                        <h2>VISION</h2>
                        <p>For the University of Makati (UMAK) community to be healthy in mind and body through competent and quality medical care.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Core Values Section -->
<section id="core-values" class="core-values-section">
    <div class="core-values-container">
        <h2>Core Values</h2>
        <div class="core-values-list">
            <div class="core-value">
                <img src="images/core3.png" alt="Professionalism Logo">
                <p>Professionalism</p>
            </div>
            <div class="core-value">
                <img src="images/core2.png" alt="Integrity Logo">
                <p>Integrity</p>
            </div>
            <div class="core-value">
                <img src="images/core1.png" alt="Excellence Logo">
                <p>Excellence</p>
            </div>
        </div>
    </div>
</section>

<div class="parallax">
<!-- Services Section -->
<section id="services" class="services-section">
    <div class="services-content">
        <div class="service">
            <h3>Medical and Dental Services</h3>
            <p>Provide Free Medical and Dental Consultation & Services to Employees and Students.</p>
        </div>

        <div class="service">
            <h3>Health Awareness</h3>
            <p>Provide programs to promote health and prevent illness to Employees and Students.</p>
        </div>

        <div class="service">
            <h3>First Aid</h3>
            <p>Provide First Aid For Medical Emergencies.</p>
        </div>
    </div>
</div>
</section>

<!-- Prescriptions Section -->
<section id="prescriptions" class="prescriptions-section">
    <div class="prescriptions-content">
        <div class="prescription">
            <h2>Prescriptions</h2>
            <p>Prescription and Issuance of Medicines</p>
        </div>

        <div class="prescription">
            <h2>Implement Policies</h2>
            <p>Formulate and implement policies & procedures for the physical & mental health of employees and students.</p>
        </div>
    </div>
</section>  
</div>
</div>
<div class="parallax"></div>

<script>
    var isConnectingToLiveAgent = false;

    function sendMessage() {
        var userInput = document.getElementById('user-input');
        var chatBox = document.getElementById('chat-box');

        var userMessage = userInput.value.trim();
        if (userMessage !== '') {
            // Display user message
            chatBox.innerHTML += '<div style="text-align: right; margin-bottom: 5px;"><p style="background-color: #4267b2; color: #fff; padding: 10px; border-radius: 5px; display: inline-block;">' + userMessage + '</p></div>';
            // Clear input field
            userInput.value = '';

            // Simulate a chatbot response
            var botResponse = getBotResponse(userMessage);

            // Display chatbot response with the response-message class
            chatBox.innerHTML += '<div style="text-align: left; margin-bottom: 5px;"><p class="response-message" style="background-color: #ddd; color: #333; padding: 10px; border-radius: 5px; display: inline-block;">' + botResponse + '</p></div>';

            // If connecting to live agent, simulate a delay and then show a response
            if (isConnectingToLiveAgent) {
                setTimeout(function () {
                    chatBox.innerHTML += '<div style="text-align: left; margin-bottom: 5px;"><p class="response-message" style="background-color: #ddd; color: #333; padding: 10px; border-radius: 5px; display: inline-block;">You are now connected to a live agent.</p></div>';
                    isConnectingToLiveAgent = false;
                    // Scroll to the bottom of the chat box
                    chatBox.scrollTop = chatBox.scrollHeight;
                }, 2000); // Simulating a 2-second delay
            } else {
                // Scroll to the bottom of the chat box
                chatBox.scrollTop = chatBox.scrollHeight;
            }
        }
    }

    function sendChoice(choice) {
        // Display user choice
        var chatBox = document.getElementById('chat-box');
        chatBox.innerHTML += '<div style="text-align: right; margin-bottom: 5px;"><p style="background-color: #4267b2; color: #fff; padding: 10px; border-radius: 5px; display: inline-block;">' + choice + '</p></div>';

        // Simulate a chatbot response based on the user's choice
        var botResponse = getBotResponse(choice);

        // Display chatbot response with the response-message class
        chatBox.innerHTML += '<div style="text-align: left; margin-bottom: 5px;"><p class="response-message" style="background-color: #ddd; color: #333; padding: 10px; border-radius: 5px; display: inline-block;">' + botResponse + '</p></div>';

        // Scroll to the bottom of the chat box
        chatBox.scrollTop = chatBox.scrollHeight;
    }

    function getBotResponse(userMessage) {
        // Replace this function with actual chatbot integration logic
        // For simplicity, using a simple response based on user input
        if (userMessage.toLowerCase().includes('clinic hours')) {
            return 'The UMak Medical and Dental Clinic is open every Mondays to Fridays, 8:00 A.M to 5:00 P.M';
        } else if (userMessage.toLowerCase().includes('location')) {
            return 'We are located in Ground Floor, Admin Bldg. of University of Makati.';
        } else if (userMessage.toLowerCase().includes('can people outside umak book an appointment here?') || userMessage.toLowerCase().includes('umak students') || userMessage.toLowerCase().includes('outsiders')) {
            return 'No, we only accept patients that study or work inside University of Makati.';
        } else if (userMessage.toLowerCase().includes('payment')) {
            return 'UMak Medical and Dental Clinic is free of charge.';
        } else if (userMessage.toLowerCase().includes('can students have a check up here?')) {
            return 'Yes, if they are a student or worker in UMak they can avail the services that we offer here.';
        } else if (userMessage.toLowerCase().includes('how to book an appointment')) {
            return 'Log-in to your Umak account first, then go to Book an Appointment and fill out the information needed. ';
        } else if (userMessage.toLowerCase().includes('services')) {
            return 'We offer free Medical, Dental and Check-up Services';
        } else {
            return "I don't quite understand your question. Can I help you with something?";
        }
        
    }

    function toggleChatbox() {
        var chatbox = document.getElementById('chat-section12');
        chatbox.style.display = (chatbox.style.display === 'none' || chatbox.style.display === '') ? 'flex' : 'none';
    }

    document.getElementById('user-input').addEventListener('keypress', function (event) {
        if (event.key === 'Enter') {
            sendMessage();
        }
    });

</script>

    
        </main>
<?php include ('footer1.html'); ?>
</body>
</html>
