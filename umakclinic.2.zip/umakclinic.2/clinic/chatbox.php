<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title> Chat box</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" integrity="sha512-FZcYfrdIbT4sa1c3njjgW/8r6RZZE8sy5n7jt7u7g5g0lHxfrk5wE5r4mPbweYdpqPX6JjFO2vNxCynKUeLzzg==" crossorigin="anonymous" referrerpolicy="no-referrer"/>
</head>
<style>
    body{
        overflow: hidden;
        background: #E3F2FD;
    }
    label{
        position: absolute;
        right: 30px;
        bottom: 20px;
        height: 55px;
        width: 55px;
        background: #4070F4;
        text-align: center;
        line-height: 55px;
        border-radius: 50px;
        font-size: 30px;
        color: #fff;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
    }
    label i.fas{
        opacity: 0;
        pointer-events: none;
    }
    #click:checked ~ label i.fas{
        opacity: 1;
        pointer-events: auto;
        transform: translate(-50%,-50%) rotate(180deg);
    }
    #click:checked ~ label i.fab{
        opacity: 0;
        pointer-events: auto;
        transform: translate(-50%,-50%) rotate(180deg);
    }

    .wrapperss{
        position: absolute;
        right: 30px;
        margin-bottom: 50px;
        max-width: 400px;
        background: #fff;
        border-radius: 8px;
        box-shadow: 0 0 8px rgba(0, 0, 0, 0.1);
        opacity: 0;
        pointer-events: none;
        transition: all 0.6s cubic-bezier(0.68,-0.55,0.265,1.55);
}
    #click:checked ~ .wrapperss{
        opacity: 1;
        bottom: 85px;
        pointer-events: auto;
    }
    .wrapperss .head-text{
        line-height: 60px;
        color: #fff;
        border-radius: 8px 8px 0 0;
        padding: 0 20px;
        font-weight: 500;
        font-size: 20px;
        background: #4070F4;
    }
    .wrapperss .chat-box{
        padding: 20px;
        width: 90%;
    }
    .chat-box .desc-text{
        color: #515365;
        text-align:center;
        line-height: 25px;
        font-size: 17px;
        font-weight: 500;
    }
    .chat-box form{
        padding: 10px 15px;
        margin: 20px 0;
        border-radius: 5px;
        border: 1px solid lightgray;
    }
    .chat-box form .field{
        height: 50px;
        width: 80%;
        margin-top: 20px;
    }
    .chat-box form .field:last-child{
        margin-bottom: 15px;
    }
    form .field input,
    form .field buttom{
        width: 100%;
        height: 100%;
        padding-left: 20px;
        border: 1px solid lightgray;
        outline: none;
        border-radius: 5px;
        font-size: 16px;
        transition: all 0.3s ease;
    }
    form .field input::placeholder{
        color: silver;
        transition: all 0.3s ease;
    }
    form .field input:focus::placeholder{
        color:lightgray;
    }
    .chat-box form .field button{
        border: none;
        outline: none;
        cursor: pointer;
        color:#fff;
        font-size: 18px;
        font-weight: 500;
        background: #4070F4;
        transition: all 0.3s ease;
    }
    .chat-box form .field button:active{
        transform: scale(0.97);
    }
    #click{
        display: none;
    }
    </style>
<body>
    
    <input type="checkbox" id="click">
    <label for="click">
        <i class="fab fa-facebook-f"></i>
        <i class="fas fa-times"></i>
    </label>    

    <div class="wrapperss">
        <div class="head-text"> Chat with us - Online </div>
        <div class="chat-box"> 
            <div class="desc-text">Please provide us with these details</div>
            <form action="#">
                <div class="field">
                    <input type="text" placeholder="Your name" required></div>
                    <div class="field">
                        <input type="text" placeholder="Email Address" required></div>
                        <div class="field">
    <button type="submit">Start Chat</button>
</div>
</form>

    </div>
</body>
</html>


