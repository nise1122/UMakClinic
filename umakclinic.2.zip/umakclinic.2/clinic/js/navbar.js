 // Responsive-navbar-active-animation
 function test() {
	var tabsNewAnim = $('#navbarSupportedContent');
	var selectorNewAnim = $('#navbarSupportedContent').find('li').length;
	var activeItemNewAnim = tabsNewAnim.find('.active');
	var activeWidthNewAnimHeight = activeItemNewAnim.innerHeight();
	var activeWidthNewAnimWidth = activeItemNewAnim.innerWidth();
	var itemPosNewAnimTop = activeItemNewAnim.position();
	var itemPosNewAnimLeft = activeItemNewAnim.position();
	$(".hori-selector").css({
		"top": itemPosNewAnimTop.top + "px",
		"left": itemPosNewAnimLeft.left + "px",
		"height": activeWidthNewAnimHeight + "px",
		"width": activeWidthNewAnimWidth + "px"
	});
	$("#navbarSupportedContent").on("click", "li", function (e) {
		$('#navbarSupportedContent ul li').removeClass("active");
		$(this).addClass('active');
		var activeWidthNewAnimHeight = $(this).innerHeight();
		var activeWidthNewAnimWidth = $(this).innerWidth();
		var itemPosNewAnimTop = $(this).position();
		var itemPosNewAnimLeft = $(this).position();
		$(".hori-selector").css({
			"top": itemPosNewAnimTop.top + "px",
			"left": itemPosNewAnimLeft.left + "px",
			"height": activeWidthNewAnimHeight + "px",
			"width": activeWidthNewAnimWidth + "px"
		});
	});
}

$(document).ready(function () {
	setTimeout(function () {
		test();
	});
});

$(window).on('resize', function () {
	setTimeout(function () {
		test();
	}, 500);
});

$(".navbar-toggler").click(function () {
	$(".navbar-collapse").slideToggle(300);
	setTimeout(function () {
		test();
	});
});

var indicator = $('.hori-selector');
var activeItem = $('#navbarSupportedContent ul li a.active');
var indicatorPosition = activeItem.position();
var indicatorWidth = activeItem.width();

indicator.css({
	"left": indicatorPosition.left + "px",
	"width": indicatorWidth + "px"
});

$('#navbarSupportedContent ul li a').hover(function () {
	indicator.css({
		"left": $(this).position().left + "px",
		"width": $(this).width() + "px"
	});
}, function () {
	indicator.css({
		"left": indicatorPosition.left + "px",
		"width": indicatorWidth + "px"
	});
});

$('#navbarSupportedContent ul li a').click(function () {
	indicator.css({
		"left": $(this).position().left + "px",
		"width": $(this).width() + "px"
	});
});

$(document).ready(function () {
    $(".navbar-toggler").click(function () {
        $(".navbar-collapse").slideToggle(300);
    });

    // Function to toggle sidebar
    function toggleSidebar() {
        var sidebar = document.getElementById("mySidebar");
        sidebar.style.width = sidebar.style.width === "250px" ? "0" : "250px";
    }

    // Listen for click events on the toggle button
    document.getElementById("toggleSidebar").addEventListener("click", function (e) {
        e.stopPropagation(); // prevent event from reaching the document
        toggleSidebar();
    });

    // Function to close sidebar when a link is clicked
    document.querySelectorAll('.sidebar-content a').forEach(function (link) {
        link.addEventListener('click', function () {
            toggleSidebar();
        });
    });
	

    // Listen for scroll events and handle scrolling effect
    window.addEventListener('scroll', function () {
        var missionVisionContainer = document.getElementById('mission-vision');
        var scrollPosition = window.scrollY;

        if (scrollPosition > 50) {
            missionVisionContainer.classList.add('transition-effect');
        } else {
            missionVisionContainer.classList.remove('transition-effect');
        }
    });

    // Close the sidebar on window resize
    window.addEventListener('resize', function () {
        var sidebar = document.getElementById("mySidebar");
        sidebar.style.width = "0";
    });

    // Add active class on another-page move
    var path = window.location.pathname.split("/").pop();
    if (path === '') {
        path = 'index.html';
    }
    var target = $('#navbarSupportedContent ul li a[href="' + path + '"]');
    target.parent().addClass('active');
});

