<!DOCTYPE html>
<html lang="en">
<head>
<link rel="icon" href="umaklogos.png">   
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Password Reset Status</title>
</head>
<body>

<?php
// Establish a database connection
$mysqli = new mysqli("localhost", "root", "", "hms");

// Check the connection
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    // Handle POST request (token provided)
    if (isset($_POST["email"]) && isset($_POST["token"])) {
        $email = $_POST["email"];
        $token = $_POST["token"];
        
        // Update the password_reset table, send email logic here...

        echo "Email sent to your Gmail account. Please check your inbox.";
    } else {
        echo "Token not provided.";
    }
} else {
    // Handle GET request (link clicked)
    if (isset($_GET["token"])) {
        $token = $_GET["token"];
        
        // Your logic to handle the token and reset the password...

        echo "Password reset link clicked.";
    } else {
        echo "Message sent to your Gmail Account, please check your inbox.";
    }
}

// Retrieve the token from the database based on the provided email
$token_query = "SELECT reset_token_hash FROM password_reset WHERE email = ? AND reset_token_expires_at > NOW()";
$stmt = $mysqli->prepare($token_query);

if ($stmt) {
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->bind_result($token_hash);

    if ($stmt->fetch()) {
        // Token found, use $token_hash
        $resetLink = "http://localhost/UMakClinic/Clinic/hms/reset-password.php?token=" . $token_hash;

        // Include the mailer class
        require __DIR__ . "/mailer.php";

        // Create a new instance of the mailer class
        $mail = new PHPMailer\PHPMailer\PHPMailer();

        // Configure the mailer
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'clinicmedicalanddental@gmail.com';
        $mail->Password = 'pcfgnydcbclcfgop';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
        $mail->Port = 465;

        // Recipients
        $mail->setFrom("baracssangel@gmail.com");
        $mail->addAddress($email);

        // Content
        $mail->isHTML(true);
        $mail->Subject = $subject;

        $mail->Body = "Click <a href=\"$resetLink\">here</a> to reset your password.";

        try {
            $mail->send();
            echo "Message sent, please check your inbox.";
        } catch (Exception $e) {
            echo "Message could not be sent. Mailer error: {$mail->ErrorInfo}";
        }
    }

    $stmt->close();
} else {
    echo "Error preparing the token query: " . $mysqli->error;
}

// Close the database connection
$mysqli->close();
?>

</body>
</html>
