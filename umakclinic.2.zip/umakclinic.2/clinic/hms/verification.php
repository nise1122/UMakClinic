<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

@include 'include/config1.php';

// Include PHPMailer library
require 'C:\xampp\htdocs\UMakClinic\vendor\autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;

$error = array();

if (isset($_POST['submit'])) {
    $email = $_SESSION['email'];
    $enteredOTP = $_POST['otp'];

    $stmt_ver = null;
$stmt_clear_otp = null;

    if (!empty($email)) {
        // Retrieve OTP from the database
        $query = "SELECT otp, status FROM users WHERE email = ?";
        $stmt = mysqli_prepare($conn, $query);
    
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "s", $email);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
    
            if ($result && mysqli_num_rows($result) > 0) {
                $row = mysqli_fetch_assoc($result);
                $storedOTP = $row['otp'];
    
                if ($row['status'] == 1) {
                    $error[] = 'User is already verified.';
                } elseif ($enteredOTP === $storedOTP) {
                    // Update status to indicate successful verification
                    $ver_query = "UPDATE users SET status = 1 WHERE email = ?";
                    $stmt_ver = mysqli_prepare($conn, $ver_query);
    
                    if ($stmt_ver) {
                        mysqli_stmt_bind_param($stmt_ver, "s", $email);
                        mysqli_stmt_execute($stmt_ver);
    
                        // Set session variable for verification status
                        $_SESSION['isVerified'] = true;
    
                        // Optionally, clear OTP field after successful verification
                        $clear_otp_query = "UPDATE users SET otp = NULL WHERE email = ?";
                        $stmt_clear_otp = mysqli_prepare($conn, $clear_otp_query);
    
                        if ($stmt_clear_otp) {
                            mysqli_stmt_bind_param($stmt_clear_otp, "s", $email);
                            mysqli_stmt_execute($stmt_clear_otp);
                        }
    
                        header('Location: user-login.php');
                        exit();
                    } else {
                        $error[] = 'Failed to prepare statement for verification update.';
                    }
                } else {
                    $error[] = 'Invalid OTP, please try again.';
                }
            } else {
                // Handle the case when OTP is not found in the database
                $error[] = 'Failed to retrieve OTP. Please try again later.';
            }
    
             // Close the statement after use
        mysqli_stmt_close($stmt);
    } else {
        $error[] = 'Failed to prepare statement for OTP retrieval.';
    }
} else {
    // Email not found in the session.
    $error[] = 'No email detected. Please try again later.';
}
// Close additional statements if they were initialized
if ($stmt_ver) {
    mysqli_stmt_close($stmt_ver);
}
if ($stmt_clear_otp) {
    mysqli_stmt_close($stmt_clear_otp);
}

// Generate and store OTP in the session
function generateOTP($length = 6)
{
    $otp = "";
    $chars = "0123456789";
    $chars_length = strlen($chars);

    for ($i = 0; $i < $length; $i++) {
        $otp .= $chars[rand(0, $chars_length - 1)];
    }

    return $otp;
}}

// Generate and send OTP
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"/>
    <title>Email Verification</title>
    <link rel="icon" href="umaklogos.png">
    <link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendor/themify-icons/themify-icons.min.css">
    <link href="vendor/animate.css/animate.min.css" rel="stylesheet" media="screen">
    <link href="vendor/perfect-scrollbar/perfect-scrollbar.min.css" rel="stylesheet" media="screen">
    <link href="vendor/switchery/switchery.min.css" rel="stylesheet" media="screen">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/plugins.css">
    <link rel="stylesheet" href="assets/css/themes/theme-1.css" id="skin_color" />

    <style>
        /* Add your custom styles here */
        body {
            font-family: 'Poppin', sans-serif; 
            text-align: center;
        }

        .form-container {
            max-width: 400px;
            margin: 50px auto;
            padding: 20px;
            background: #fff;
            border: 1px solid #ddd;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        .error-msg {
            color: #d9534f; 
            margin-bottom: 15px;
        }

        .reg-button {
            background-color: #0583D2; 
            color: #fff;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <form action="" method="POST">
            <h3>Email Verification</h3>
            <?php
            if (!empty($error)) {
                foreach ($error as $err) {
                    echo '<span class="error-msg">' . $err . '</span>';
                }
            }
            ?>
            <input type="text" name="otp" placeholder="Enter your OTP" maxlength="10" required>
            <div class="controls">
                <div class="button">
                    <input type="submit" name="submit" value="Submit" class="reg-button">
                </div>
            </div>
        </form>
    </div>
</body>
</html>
