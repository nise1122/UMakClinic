<?php
if (isset($_POST["email"])) {
    $email = $_POST["email"];

    $token = bin2hex(random_bytes(16));

    $token_hash = hash("sha256", $token);
    $expiry = date("Y-m-d H:i:s", time() + 60 * 30);

@include 'include/config1.php';

    $sql = "UPDATE password_reset SET reset_token_hash = ?, reset_token_expires_at = ? WHERE email = ?";
    $stmt = $mysqli->prepare($sql);

    if ($stmt) {
        $stmt->bind_param("sss", $token_hash, $expiry, $email);
        $stmt->execute();

        $mailerPath = _DIR_ . "/mailer.php";

if (file_exists($mailerPath)) {
    $mail = require $mailerPath;

            $mail->setFrom("umakmedicalanddentalclinic@gmail.com");
            $mail->addAddress($email);
            $mail->Subject = "Password Reset";
            $mail->Body = <<<END
Click <a href="https://university-of-makati-medical-anddental-clinic.000webhostapp.com/hms/reset.php?token=$token">here</a>
to reset your password.
END;


            try {
        $mail->send();
        echo "Message sent, please check your inbox.";
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer error: {$mail->ErrorInfo}";
    }
} else {
    echo "Error: mailer.php not found.";
}

        $stmt->close();
    } else {
        echo "Error preparing the update statement: " . $mysqli->error;
    }

    $mysqli->close();
} else {
    echo "Message sent to your Gmail account, please check your inbox";
}
?>
<html lang="en">
	<head>
		<title>Patient Password Recovery</title>
							<meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes, minimum-scale=1.0, maximum-scale=10.0">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">

	</head>
</html>