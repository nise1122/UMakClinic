<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    session_start();

    // Check if user is logged in
    if (!isset($_SESSION['id'])) {
        header("Location: login.php"); // Redirect to login page or handle accordingly
        exit();
    }

    // Check if file was uploaded without errors
    if (isset($_FILES['user_image']) && $_FILES['user_image']['error'] === UPLOAD_ERR_OK) {
        $target_dir = __DIR__ . DIRECTORY_SEPARATOR . "uploads" . DIRECTORY_SEPARATOR;

        // Check if the "uploads" directory exists, create it if not
        if (!file_exists($target_dir) && !mkdir($target_dir, 0755, true)) {
            die("Failed to create uploads directory");
        }

        $target_file = $target_dir . basename($_FILES['user_image']['name']);

        // Move the uploaded file to the specified directory
        if (move_uploaded_file($_FILES['user_image']['tmp_name'], $target_file)) {
            // Update the user's profile image in the database
            $con = mysqli_connect('localhost', 'root', '', 'hms', 3306);

            if (!$con) {
                die("Connection failed: " . mysqli_connect_error());
            }

            $image_path = mysqli_real_escape_string($con, $target_file);
            $user_id = $_SESSION['id'];
            $update_query = "UPDATE users SET profile_image='$image_path' WHERE id='$user_id'";
            
            if (mysqli_query($con, $update_query)) {
                header("Location: edit-profile.php");
                exit();
            } else {
                echo "Error updating profile image in the database: " . mysqli_error($con);
            }
        } else {
            echo "Error moving uploaded file.";
        }
    } else {
        echo "Error uploading file.";
    }
}
?>
