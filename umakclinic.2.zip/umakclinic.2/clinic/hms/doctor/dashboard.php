<?php
session_start();
error_reporting(0);
include('include/config.php');
include('include/checklogin.php');
check_login();

// Check if there are any notifications
$notifications = array();

// Example: Check if there are upcoming appointments within the next 24 hours
$currentDateTime = date("Y-m-d H:i:s");

// Check for new appointments
$newAppointmentQuery = "SELECT * FROM appointment WHERE doctorId = '{$_SESSION['id']}' AND appointmentDate > '{$currentDateTime}' AND status = '1'";
$newAppointmentResult = mysqli_query($con, $newAppointmentQuery);

if ($newAppointmentResult) {
    $newAppointmentsCount = mysqli_num_rows($newAppointmentResult);

    if ($newAppointmentsCount > 0) {
        $notifications[] = "You have {$newAppointmentsCount} new appointment(s).";
    }
}

// Example: Check if there are upcoming appointments within the next 24 hours
$upcomingAppointmentQuery = "SELECT * FROM appointment WHERE doctorId = '{$_SESSION['id']}' AND appointmentDate > '{$currentDateTime}'";
$upcomingAppointmentResult = mysqli_query($con, $upcomingAppointmentQuery);

if ($upcomingAppointmentResult) {
    $upcomingAppointmentsCount = mysqli_num_rows($upcomingAppointmentResult);

    if ($upcomingAppointmentsCount > 0) {
        $notifications[] = "You have {$upcomingAppointmentsCount} upcoming appointment(s) within the next 24 hours.";
    }
}

// Example: Check if there are canceled appointments
$canceledAppointmentQuery = "SELECT * FROM appointment WHERE doctorId = '{$_SESSION['id']}' AND doctorStatus = '0'";
$canceledAppointmentResult = mysqli_query($con, $canceledAppointmentQuery);

if ($canceledAppointmentResult) {
    $canceledAppointmentsCount = mysqli_num_rows($canceledAppointmentResult);

    if ($canceledAppointmentsCount > 0) {
        $notifications[] = "You have {$canceledAppointmentsCount} canceled appointment(s).";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>Doctor | Dashboard</title>
    <link rel="icon" href="umaklogos1.png">
    <link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="vendor/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="vendor/fontawesome/css/font-awesome.min.css">
    <link rel="stylesheet" href="vendor/themify-icons/themify-icons.min.css">
    <link href="vendor/animate.css/animate.min.css" rel="stylesheet" media="screen">
    <link href="vendor/perfect-scrollbar/perfect-scrollbar.min.css" rel="stylesheet" media="screen">
    <link href="vendor/switchery/switchery.min.css" rel="stylesheet" media="screen">
    <link href="vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.css" rel="stylesheet" media="screen">
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="screen">
    <link href="vendor/bootstrap-datepicker/bootstrap-datepicker3.standalone.min.css" rel="stylesheet" media="screen">
    <link href="vendor/bootstrap-timepicker/bootstrap-timepicker.min.css" rel="stylesheet" media="screen">
    <link rel="stylesheet" href="assets/css/styles.css">
    <link rel="stylesheet" href="assets/css/plugins.css">
    <link rel="stylesheet" href="assets/css/themes/theme-1.css" id="skin_color" />
    
	<style>
        .panel-no-radius {
            border-radius: 10px;
        }

        .dashboard-panel {
            height: 200px;
            padding: 30px;
            text-align: center;
            margin-bottom: 20px;
            border: 1px solid #ddd;
            background-color: #f1f5f8;
            transition: box-shadow 0.3s ease;
        }

        .dashboard-panel:hover {
            box-shadow: 0 0 60px rgba(0, 0, 0, 0.1);
        }

        .dashboard-panel h2 {
            font-size: 27px;
			font-weight: bold;
            margin-top: 20px;
        }

        .dashboard-panel p {
            font-size: 16px;
            color: #333;
            margin-top: 10px;
        }

        .dashboard-panel a {
            color: #3498db;
            text-decoration: none;
        }

        .dashboard-panel a:hover {
            color: #1a5276;
        }

    </style>
</head>
<body>
<div id="app">
    <?php include('include/sidebar.php'); ?>
    <div class="app-content">
        <?php include('include/header.php'); ?>
        <div class="main-content">
            <div class="wrap-content container" id="container">
			<section id="page-title">
    <div class="row">
        <div class="col-sm-8">
            <h1 class="mainTitle" style="background-image: url('images/docdash.png'); background-size: cover; background-position: center; color: black; padding: 20px;">Doctor | Dashboard</h1>
        </div>
    </div>
</section>

                <div class="container-fluid container-fullw bg-white">
                    <div class="row">
                        <div class="col-sm-4">
                            <div class="dashboard-panel panel-no-radius">
                                <h2>My Profile</h2>
                                <p class="links cl-effect-1">
                                    <a href="edit-profile.php">
                                        Update Profile
                                    </a>
                                </p>
                            </div>
                        </div>
                        <div class="col-sm-4">
    <div class="dashboard-panel panel-no-radius">
        <h2>My Appointments</h2>
        <p class="links cl-effect-1">
                                    <a href="appointment-history.php">
                                        Appointment History
                                    </a>
                                </p>
                                
    </div>
</div>


                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- start: SETTINGS -->
<?php include('include/setting.php');?>
			
			<!-- end: SETTINGS -->
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
<script src="vendor/modernizr/modernizr.js"></script>
<script src="vendor/jquery-cookie/jquery.cookie.js"></script>
<script src="vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
<script src="vendor/switchery/switchery.min.js"></script>
<script src="vendor/maskedinput/jquery.maskedinput.min.js"></script>
<script src="vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
<script src="vendor/autosize/autosize.min.js"></script>
<script src="vendor/selectFx/classie.js"></script>
<script src="vendor/selectFx/selectFx.js"></script>
<script src="vendor/select2/select2.min.js"></script>
<script src="vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
<script src="vendor/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
<script src="assets/js/main.js"></script>
<script src="assets/js/form-elements.js"></script>
<script>
    jQuery(document).ready(function () {
        Main.init();
        FormElements.init();
    });
</script>
</body>
</html>
