<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require __DIR__ . '/../vendor/autoload.php';

// Configure PHPMailer
$mail = new PHPMailer(true);
//$mail->SMTPDebug::DEBUG_SERVER;

$mail->isSMTP();
$mail->Host = 'smtp.gmail.com';  
$mail->SMTPAuth = true;
$mail->Username = 'baracssangel@gmail.com';  
$mail->Password = 'pfrbagebbeamuksv';  
$mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
$mail->Port = 465;

$mail->isHTML(true);
$mail->SMTPDebug = SMTP::DEBUG_SERVER; // Add this line for debugging


return $mail;
