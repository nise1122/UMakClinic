<?php
// update-image.php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    session_start();
    
    // Check if user is logged in
    if (!isset($_SESSION['id'])) {
        header("Location: login.php"); // Redirect to login page or handle accordingly
        exit();
    }

    // Check if file was uploaded without errors
    if (isset($_FILES['user_image']) && $_FILES['user_image']['error'] === UPLOAD_ERR_OK) {
        $target_dir = "uploads/"; // Change this to your desired upload directory
        $target_file = $target_dir . basename($_FILES['user_image']['name']);

        // Move the uploaded file to the specified directory
        if (move_uploaded_file($_FILES['user_image']['tmp_name'], $target_file)) {
            // Update the user's profile image in the database
            $con = mysqli_connect("your_host", "your_username", "your_password", "your_database");
            $image_path = mysqli_real_escape_string($con, $target_file);
            $user_id = $_SESSION['id'];
            $update_query = "UPDATE users SET profile_image='$image_path' WHERE id='$user_id'";
            mysqli_query($con, $update_query);

            // Redirect back to the profile page or wherever you want
            header("Location: edit-profile.php");
            exit();
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    } else {
        echo "File upload error.";
    }
} else {
    echo "Invalid request.";
}
?>
