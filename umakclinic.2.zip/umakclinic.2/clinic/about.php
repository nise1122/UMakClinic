<!DOCTYPE HTML>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Medical and Dental Clinic</title>
    <link rel="stylesheet" href="css/navstyle.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="about.css">
    <link rel="icon" href="umaklogo.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css"
        integrity="sha384-wvfXpqpZZVQGK6TAh5PVlK3uPfNfexUEFpy+JcPXdA0R+5dFZtFm4nFj1cO5N2+7" crossorigin="anonymous">
    <link href='http://fonts.googleapis.com/css?family=Ropa+Sans' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="css/responsiveslides.css">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">

</head>
<style>
    .image-slider {
    max-width: 800px;
    margin: 0 auto;
    margin-top: 150px;
    text-align: center;
    margin-left: 330px;
}


      #slider1 img {
          width: 100%;
          height: auto;
          border: 3px solid #007bff;
          border-radius: 9px;
      }
      @media (max-width: 700px) {
        .image-slider {
            margin-top: 200px;
            margin-left: 100px;
        }
        @media (max-width: 768px) {
    .service-item {
        flex-basis: calc(100% - 20px);
    }
}
    }


    </style>
<body>

    <!-- Main content -->
    <main>
        <!--start-header-->
        <div class="header">
            <div class="wrap">
                <!--start-logo-->
                <nav class="navbar navbar-expand-custom navbar-mainbg fixed-top">
                    <div class="logo-container">
                        <img src="logomed.png" style="max-height: 70px; margin-right: 3px;">
                        <div class="text-container">
                            <span class="navbar-brand navbar-logo clinic-name">MEDICAL AND DENTAL CLINIC</span>
                        </div>
                    </div>

                    <button class="navbar-toggler" type="button" aria-controls="navbarSupportedContent"
                        aria-expanded="false" aria-label="Toggle navigation">
                        <i class="fas fa-bars "></i>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav ml-auto">
                            <li class="nav-item">
                                <a class="nav-link" href="index.php"><i class="fas fa-home"></i>HOME</a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-link" href="about.php"><i class="far fa-address-book"></i>ABOUT</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="contact.php"><i class="far fa-envelope"></i>CONTACT</a>
                            </li>
                        </ul>
                    </div>
                </nav>
                <!--end-top-nav-->
            </div>
        </div>

        <!-- Parallax Image Slider -->
        <div class="parallax">
            <div class="clear"></div>
            <!--start-image-slider---->
            <div class="image-slider">
                <!-- Slideshow 1 -->
                <ul class="rslides" id="slider1">
                    <li><img src="images/slider-image3.jpg" alt=""></li>
                    <li><img src="images/slider-image9.png" alt=""></li>
                    <li><img src="images/slider-image5.jpg" alt=""></li>
                </ul>
            </div>
            <!--End-image-slider---->
        </div>
        

         <!-- Services Section -->
         <section id="services">
            <div class="service-columns">
                <div class="service-item">
                    <div class="icon">
                        <img src="images/logomed.png" alt="Icon">
                        <p>MEDICAL SERVICES</p>
                    </div>
                    <h4>Physical examination of new students</h4>
                    <h4>Annual Physical exam for employees</h4>
                    <h4>medical consultation</h4>
                    <h4>first aid for medical emergencies</h4>
                    <h4>blood pressure monitoring </h4>
                    <h4>prescription and issuance of medicines </h4>
                    <h4>issuance of referrals and medical certificates </h4>
                    <h4>hospital / home visit </h4>
                    <h4>health seminars </h4>
                    <h4>blood request assistance </h4>
                </div>

                    <div class="service-item">
                    <div class="icon">
                        <img src="images/logomed.png" alt="Icon">
                        <p>DENTAL SERVICES</p>
                    </div>
                    <h4>dental consultation</h4>
                    <h4>Annual dental exam of employees</h4>
                    <h4>oral examination of new students</h4>
                    <h4>prescription and issuance of medicine</h4>
                    <h4>issuance of dental referrals and dental certificates </h4>
                    <h4>simple tooth extraction </h4>
                    <h4>tooth restoration </h4>
                    <h4>gum treatment </h4>
                    <h4>attend to oral emergency cases </h4>
                </div>
</div>
</div>
</section>

<div class="parallax"></div>
     <!-- Staff Section -->
     <h2>OUR STAFF</h2>

<table>
    <thead>
        <tr>
            <th>Name</th>
            <th>Role</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>ALAN ANGELO N. RAYMUNDO, MD</td>
            <td>Section Head, Medical Services</td>
        </tr>
        <tr>
            <td>MARIA LINDA H. RAMIREZ, MD</td>
            <td>Department Head</td>
        </tr>    
        <tr>
            <td>ROWENA N. ALVAREZ, RN</td>
            <td>Head Nurse</td>
        </tr>  
        <tr>
            <td>JOHN JAMESON G. CRUZ, RN</td>
            <td>Nurse</td>
        </tr>  
        <tr>
            <td>ARI BEN P. APUGAN, RN</td>
            <td>Nurse</td>
        </tr>  
        <tr>
            <td>MARICRIS C. NACINOPA, RN</td>
            <td>Nurse</td>
        </tr>  
        <tr>
            <td>CELY P. MOLINES, DMD</td>
            <td>Section Head, Dental Services</td>
        </tr>  
        <tr>
            <td>VANESSA C. SALIRE, DMD</td>
            <td>Dentist</td>
        </tr>  
    
    </tbody>
</table>


<!-- Table for Forms and Downloads -->
 <div class="downloads-table">
        <table>
            <tr>
                <th>File</th>
                <th>Link</th>
            </tr>
            <tr>
                <td>Medical and Dental Form (Please print back to back in long bond paper)</td>
                <td>
                    <a href="MEDICAL FORM STUDENT 2023 FILLABLE FORM.pdf" target="_blank">Download | PDF</h1>
                </td>
            </tr>
            <tr>
                <td>Medical Referral Slip for First Year Students / Grade 11 Students</td>
                <td>
                    <a href="REFERRAL SLIP for Grade 11 and 1st Year students.pdf" target="_blank">View | PDF</a>
                </td>
            </tr>
            <tr>
                <td>Medical Referral Slip for Nursing, Pharmacy and Rad Tech First Year Students</a>
                <td>
                    <a href="Nursing pharma radtech 1st yr.pdf" target="_blank">View | PDF</a>
                </td>
            </tr>
        </table>
    </div>
    </div>

    </main>

    <?php include('footer1.html'); ?>

    <!-- Include scripts just before closing </body> tag -->
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js"></script>
    <script src="js/responsiveslides.min.js"></script>
    <script src="js/navbar.js"></script>

    <script>
        $(document).ready(function () {
            // Slideshow 1
            $("#slider1").responsiveSlides({
                maxwidth: 1600,
                speed: 400
            });
        });
    </script>

</body>

</html>
