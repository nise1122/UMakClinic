<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Medical and Dental Clinic - University of Makati</title>
    <link rel="stylesheet" href="css/navstyle.css" type="text/css" media="all" />
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="index1.css">
    <link rel="icon" href="umaklogo.png">
    <link href='http://fonts.googleapis.com/css?family=Ropa+Sans' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="css/responsiveslides.css">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
</head>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            line-height: 1.6;
            background-color: #f8f8f8;
            color: #333;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #337CCF;
            color: white;
            text-align: center;
            padding: 1em;
        }

        section {
            max-width: 800px;
            margin: 0 auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-top: 20px;
            border-radius: 5px;
            text-align: justify;
        }

        h2, h3 {
            color: #337CCF;
        }

        p {
            margin-bottom: 15px;
        }

        ul {
            list-style: none;
            padding: 0;
        }

        li {
            margin-bottom: 8px;
        }

    </style>
</head>

<body>
    <div class="header">
        <div class="wrap">
        <nav class="navbar navbar-expand-custom navbar-mainbg">
        <div class="logo-container">
        <img src="logomed.png" style="max-height: 70px; margin-right: 3px;">
            <span class="navbar-brand navbar-logo clinic-name">MEDICAL AND DENTAL CLINIC</span>
        </div>

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
            aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <i class="fas fa-bars"></i>
        </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item active">
                            <a class="nav-link" href="index.php"><i class="fas fa-home"></i>HOME</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="about.php"><i class="far fa-address-book"></i>ABOUT</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="contact.php"><i class="far fa-envelope"></i>CONTACT</a>
                        </li>
                    </ul>
                </div>
            </nav>
        </div>
    </div>

    <header>
        <h1>University of Makati Clinic</h1>
    </header>

    <section>
        <h2>Terms and Conditions</h2>
        <p><strong>1. Acceptance of Terms</strong></p>
        <p>By signing up and engaging with the features provided on the University of Makati Clinic website, users explicitly agree to adhere to and comply with the stipulations outlined in these Terms of Service.</p>

        <p><strong>2. Account Security</strong></p>
        <p>Users bear the responsibility of ensuring the security and confidentiality of their accounts. It is imperative that login credentials remain private, and any unauthorized access or suspicious activities are promptly reported to us for immediate investigation and resolution.</p>

        <p><strong>3. Medical Information</strong></p>
        <p>The medical information disseminated through this platform is intended solely for educational purposes. It is not a substitute for professional medical advice, diagnosis, or treatment. Users are encouraged to seek guidance from qualified healthcare professionals for their specific medical concerns.</p>

        <p><strong>4. User Conduct</strong></p>
        <p>Users are expected to conduct themselves with the utmost ethical and respectful behavior while utilizing the University of Makati Clinic website. Any form of harassment, abuse, or unauthorized access to other user accounts is strictly prohibited and may result in account termination.</p>

        <p><strong>5. Privacy</strong></p>
        <p>We prioritize the privacy of our users. Detailed information regarding the collection, utilization, and protection of personal data is outlined in our Privacy Policy. Users are encouraged to review this policy to gain a comprehensive understanding of how their personal information is managed.</p>

        <p><strong>6. Modifications</strong></p>
        <p>The University of Makati Clinic reserves the right to modify or update these Terms of Service at its discretion. Users will be duly notified of any such changes, and continued use of the website following modifications indicates acceptance of the revised terms.</p>

        <p><strong>7. Termination</strong></p>
        <p>The University of Makati Clinic reserves the right to terminate user accounts in the event of a violation of these terms or for reasons deemed necessary to uphold the integrity and security of the platform.</p>

        <h2>Privacy Policy</h2>
        <p><strong>1. Information We Collect</strong></p>
        <p>We collect personal information from students during the signup process, including but not limited to name, contact information, and student ID. This information is used for medical appointment scheduling and communication.</p>

        <p><strong>2. Use of Information</strong></p>
        <p>Personal information is used solely for providing medical services and improving the user experience. We do not share personal information with third parties without explicit consent.</p>

        <p><strong>3. Data Security</strong></p>
        <p>We implement robust security measures to protect personal information from unauthorized access, disclosure, alteration, and destruction.</p>

        <p><strong>4. Student Health Records</strong></p>
        <p>Medical information shared on this platform is considered sensitive. We adhere to strict confidentiality standards in handling student health records.</p>

        <p><strong>5. Third-Party Services</strong></p>
        <p>We may use third-party services for analytics and communication. These services adhere to their own privacy policies, and we are not responsible for their practices.</p>

        <h2>Cookies Policy</h2>
        <p><strong>Why do we use cookies?</strong></p>
        <p>We use cookies for several essential purposes to enhance user experience and improve our website's functionality. Cookies assist in maintaining user sessions, ensuring that students remain logged in during their visit. Cookies enable us to remember user preferences, providing a more tailored and user-friendly website experience. We utilize cookies for website analytics, gathering information about user interactions. This data is anonymized and helps us analyze and enhance the performance of our medical system.</p>

        <p><strong>Security</strong></p>
        <p>Cookies contribute to the security of user accounts by detecting and preventing unauthorized access. Users have the option to control and delete cookies through their browser settings, although disabling cookies may impact website functionality. It's important to note that essential cookies are necessary for the website's basic functionality, and continued use implies consent to their use. Our Cookies Policy may be updated or modified, and users will be notified of any changes. By continuing to use the website after modifications, users indicate acceptance of the updated policy.</p>

    </section>

    <?php include ('footer1.html'); ?>

</body>

</html>
