-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 01, 2023 at 11:36 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `updationDate` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`, `updationDate`) VALUES
(1, 'admin', '1234567890', '22-11-2023 01:02:24 PM');

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `id` int(11) NOT NULL,
  `doctorSpecialization` varchar(255) DEFAULT NULL,
  `doctorId` int(11) DEFAULT NULL,
  `userId` int(11) DEFAULT NULL,
  `appointmentDate` varchar(255) DEFAULT NULL,
  `appointmentTime` varchar(255) DEFAULT NULL,
  `postingDate` timestamp NULL DEFAULT current_timestamp(),
  `userStatus` int(11) DEFAULT NULL,
  `doctorStatus` int(11) DEFAULT NULL,
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`id`, `doctorSpecialization`, `doctorId`, `userId`, `appointmentDate`, `appointmentTime`, `postingDate`, `userStatus`, `doctorStatus`, `updationDate`) VALUES
(53, 'Dentist', 12, 1, '2023-11-29', '1:45 PM', '2023-11-26 14:37:18', 1, 1, NULL),
(54, 'Internal Medicine', 0, 1, '2023-11-29', '4:15 PM', '2023-11-27 08:15:59', 1, 1, NULL),
(55, 'Internal Medicine', 20, 45, '2023-11-29', '5:30 PM', '2023-11-28 09:17:45', 1, 1, NULL),
(56, 'Internal Medicine', 20, 45, '2023-11-28', '3:00 PM', '2023-11-29 06:56:25', 1, 1, NULL),
(57, 'Dentist', 12, 45, '2023-11-30', '3:15 PM', '2023-11-29 07:09:39', 1, 0, '2023-12-01 01:05:18'),
(58, 'Dentist', 12, 45, '2023-11-29', '3:15 AM', '2023-11-29 07:11:53', 1, 2, '2023-12-01 01:05:30'),
(59, 'Dentist', 12, 44, '2023-12-01', '10:00 AM', '2023-11-30 01:54:30', 1, 1, NULL),
(60, 'Dentist', 12, 45, '2023-12-01', '9:15 AM', '2023-12-01 01:03:50', 0, 1, '2023-12-01 01:06:23'),
(61, 'Dentist', 12, 45, '2023-12-02', '9:15 AM', '2023-12-01 01:05:56', 1, 1, NULL),
(62, 'Dentist', 12, 45, '2023-12-02', '10:00 AM', '2023-12-01 01:06:14', 1, 1, NULL),
(64, 'Dentist', 12, 48, '2023-12-18', '10:15 AM', '2023-12-01 02:05:00', 1, 2, '2023-12-01 02:05:41'),
(65, 'Dentist', 12, 48, '2023-12-05', '10:15 AM', '2023-12-01 02:06:31', 1, 0, '2023-12-01 02:07:23'),
(66, 'Dentist', 12, 48, '2023-12-06', '10:15 AM', '2023-12-01 02:11:39', 1, 1, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `audit_log`
--

CREATE TABLE `audit_log` (
  `id` int(11) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone_number` varchar(15) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `status` varchar(20) DEFAULT NULL,
  `role_name` varchar(50) DEFAULT NULL,
  `modify_user` varchar(255) DEFAULT NULL,
  `date_time` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `doctors`
--

CREATE TABLE `doctors` (
  `id` int(11) NOT NULL,
  `specilization` varchar(255) DEFAULT NULL,
  `doctorName` varchar(255) DEFAULT NULL,
  `address` longtext DEFAULT NULL,
  `contactno` bigint(11) DEFAULT NULL,
  `docEmail` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT current_timestamp(),
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `doctors`
--

INSERT INTO `doctors` (`id`, `specilization`, `doctorName`, `address`, `contactno`, `docEmail`, `password`, `creationDate`, `updationDate`) VALUES
(12, 'Dentist', 'Angela Maria Baracol', '142 Barangay Rizal', 1234567890, 'angelabaracol@gmail.com', 'e807f1fcf82d132f9bb018ca6738a19f', '2023-11-11 04:28:05', '2023-11-22 08:01:38'),
(13, 'Dentist', 'Vanessa Salire', '4333 tinio st. bangkal makati', 9282690953, 'angelicabaracol@gmail.com', 'e807f1fcf82d132f9bb018ca6738a19f', '2023-11-11 04:33:26', '2023-11-21 05:57:36'),
(15, 'Internal Medicine', 'Alan Angelo Raymundo', 'Mandaluyong', 3213421, 'alanangelo.raymundo@umak.edu.ph', '75dd07917dac4a7d0c986c97776eb3bc', '2023-11-21 06:02:16', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `doctorslog`
--

CREATE TABLE `doctorslog` (
  `id` int(11) NOT NULL,
  `uid` int(11) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `userip` binary(16) DEFAULT NULL,
  `loginTime` timestamp NULL DEFAULT current_timestamp(),
  `logout` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `doctorslog`
--

INSERT INTO `doctorslog` (`id`, `uid`, `username`, `userip`, `loginTime`, `logout`, `status`) VALUES
(59, 12, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-14 06:22:27', '14-11-2023 11:58:11 AM', 1),
(60, 12, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-14 06:29:47', '14-11-2023 12:00:45 PM', 1),
(61, NULL, 'abaracol.k11938992@umak.edu.ph', 0x3a3a3100000000000000000000000000, '2023-11-19 03:36:33', NULL, 0),
(62, 12, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-19 04:22:07', '19-11-2023 09:52:52 AM', 1),
(63, 12, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-19 09:37:44', '19-11-2023 03:21:13 PM', 1),
(64, 12, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-19 10:07:32', '19-11-2023 03:40:03 PM', 1),
(65, 12, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-19 15:46:03', '19-11-2023 09:16:41 PM', 1),
(66, 12, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-19 15:48:01', '19-11-2023 09:19:31 PM', 1),
(67, 12, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-19 15:50:39', '19-11-2023 09:28:44 PM', 1),
(68, 12, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-20 05:53:08', '20-11-2023 06:43:19 PM', 1),
(69, 12, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-21 05:40:52', '21-11-2023 11:26:32 AM', 1),
(70, 12, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-21 12:23:10', NULL, 1),
(71, 12, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-22 07:37:10', '22-11-2023 01:08:13 PM', 1),
(72, NULL, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-22 07:38:25', NULL, 0),
(73, NULL, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-22 07:38:34', NULL, 0),
(74, NULL, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-22 07:38:45', NULL, 0),
(75, NULL, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-22 07:38:52', NULL, 0),
(76, 12, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-22 07:39:06', '22-11-2023 01:11:18 PM', 1),
(77, 12, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-22 07:41:26', '22-11-2023 01:11:47 PM', 1),
(78, 12, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-22 07:46:01', '22-11-2023 01:18:29 PM', 1),
(79, 12, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-22 08:47:34', '22-11-2023 02:43:01 PM', 1),
(80, 12, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-22 09:16:35', '22-11-2023 02:55:06 PM', 1),
(81, 12, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-22 09:27:02', '22-11-2023 03:12:59 PM', 1),
(82, 12, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-22 09:44:00', '22-11-2023 03:17:35 PM', 1),
(83, 12, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-22 09:48:22', '22-11-2023 03:20:48 PM', 1),
(84, 12, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-22 09:51:49', '22-11-2023 03:24:56 PM', 1),
(85, 12, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-22 09:57:23', '22-11-2023 03:40:32 PM', 1),
(86, 12, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-22 10:11:27', '22-11-2023 04:21:15 PM', 1),
(87, 12, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-22 10:52:39', '22-11-2023 04:50:52 PM', 1),
(88, NULL, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-22 11:33:19', NULL, 0),
(89, 12, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-22 11:33:29', '22-11-2023 05:06:56 PM', 1),
(90, 12, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-22 11:41:37', '22-11-2023 06:12:59 PM', 1),
(91, 12, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-22 12:44:19', NULL, 1),
(92, 12, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-23 04:41:35', '23-11-2023 10:15:00 AM', 1),
(93, 12, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-23 04:58:54', NULL, 1),
(94, 12, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-24 04:24:19', NULL, 1),
(95, 12, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-25 04:46:41', NULL, 1),
(96, 20, 'melvintolentino@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-25 05:16:44', NULL, 1),
(97, 20, 'melvintolentino@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-25 05:24:18', NULL, 1),
(98, 20, 'melvintolentino@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-25 05:30:28', NULL, 1),
(99, 20, 'melvintolentino@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-25 05:32:05', '25-11-2023 11:03:36 AM', 1),
(100, 20, 'melvintolentino@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-25 05:33:44', NULL, 1),
(101, 20, 'melvintolentino@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-25 05:34:34', NULL, 1),
(102, 20, 'melvintolentino@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-25 07:03:47', '25-11-2023 12:36:56 PM', 1),
(103, 20, 'melvintolentino@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-25 07:08:31', '25-11-2023 01:17:06 PM', 1),
(104, 20, 'melvintolentino@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-25 07:47:23', '25-11-2023 01:47:59 PM', 1),
(105, 20, 'melvintolentino@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-25 08:35:08', '25-11-2023 02:15:53 PM', 1),
(106, 20, 'melvintolentino@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-25 08:47:13', '25-11-2023 02:17:45 PM', 1),
(107, 20, 'melvintolentino@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-25 08:47:56', NULL, 1),
(108, 20, 'melvintolentino@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-26 05:32:59', '26-11-2023 11:14:49 AM', 1),
(109, 20, 'melvintolentino@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-26 05:45:00', '26-11-2023 11:18:03 AM', 1),
(110, 20, 'melvintolentino@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-26 05:48:12', '26-11-2023 11:28:04 AM', 1),
(111, 20, 'melvintolentino@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-26 05:58:12', '26-11-2023 11:29:46 AM', 1),
(112, 20, 'melvintolentino@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-26 05:59:54', NULL, 1),
(113, NULL, 'melvintolentino@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-26 06:53:20', NULL, 0),
(114, 20, 'melvintolentino@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-26 06:53:27', '26-11-2023 12:29:37 PM', 1),
(115, NULL, 'melvintolentino@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-26 07:00:07', NULL, 0),
(116, 20, 'melvintolentino@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-26 07:00:14', '26-11-2023 12:30:20 PM', 1),
(117, 20, 'melvintolentino@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-26 11:22:06', '26-11-2023 04:52:20 PM', 1),
(118, NULL, 'melvintolentino@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-26 11:23:53', NULL, 0),
(119, 20, 'melvintolentino@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-26 11:24:07', '26-11-2023 06:05:19 PM', 1),
(120, 20, 'melvintolentino@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-26 12:36:10', NULL, 1),
(121, 20, 'melvintolentino@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-26 12:43:41', '26-11-2023 06:15:55 PM', 1),
(122, 20, 'melvintolentino@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-26 12:46:03', NULL, 1),
(123, 20, 'melvintolentino@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-26 12:47:44', NULL, 1),
(124, 12, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-26 12:55:34', '26-11-2023 06:27:21 PM', 1),
(125, 20, 'melvintolentino@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-26 13:58:40', '26-11-2023 07:30:27 PM', 1),
(126, 20, 'melvintolentino@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-26 14:00:36', NULL, 1),
(127, 20, 'melvintolentino@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-26 14:38:04', '26-11-2023 08:08:07 PM', 1),
(128, 12, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-26 14:38:17', '26-11-2023 08:09:05 PM', 1),
(129, 12, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-28 09:16:11', '28-11-2023 02:46:37 PM', 1),
(130, 20, 'melvintolentino@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-28 09:16:48', '28-11-2023 02:47:20 PM', 1),
(131, 20, 'melvintolentino@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-28 09:19:39', '28-11-2023 02:52:58 PM', 1),
(132, 20, 'melvintolentino@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-29 06:57:02', NULL, 1),
(133, 12, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-29 07:09:54', '29-11-2023 12:40:05 PM', 1),
(134, 12, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-29 07:12:05', '29-11-2023 12:42:43 PM', 1),
(135, 20, 'melvintolentino@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-29 07:12:53', '29-11-2023 12:51:00 PM', 1),
(136, 12, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-29 07:21:40', '29-11-2023 12:51:46 PM', 1),
(137, 20, 'melvintolentino@gmail.com', 0x3a3a3100000000000000000000000000, '2023-11-29 07:21:56', '29-11-2023 12:52:04 PM', 1),
(138, 12, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-12-01 00:53:11', '01-12-2023 06:31:44 AM', 1),
(139, 12, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-12-01 01:04:27', '01-12-2023 06:35:34 AM', 1),
(140, 12, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-12-01 01:06:45', '01-12-2023 06:50:39 AM', 1),
(141, 12, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-12-01 02:05:17', '01-12-2023 07:35:49 AM', 1),
(142, NULL, 'abaracol.k11938992@umak.edu.ph', 0x3a3a3100000000000000000000000000, '2023-12-01 02:06:00', NULL, 0),
(143, NULL, 'abaracol.k11938992@umak.edu.ph', 0x3a3a3100000000000000000000000000, '2023-12-01 02:06:45', NULL, 0),
(144, 12, 'angelabaracol@gmail.com', 0x3a3a3100000000000000000000000000, '2023-12-01 02:06:53', '01-12-2023 07:38:00 AM', 1);

-- --------------------------------------------------------

--
-- Table structure for table `doctorspecilization`
--

CREATE TABLE `doctorspecilization` (
  `id` int(11) NOT NULL,
  `specilization` varchar(255) DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT current_timestamp(),
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `doctorspecilization`
--

INSERT INTO `doctorspecilization` (`id`, `specilization`, `creationDate`, `updationDate`) VALUES
(15, 'Dentist', '2023-11-19 16:02:31', '2023-11-19 16:03:03'),
(16, 'Dermatologist', '2023-11-19 16:02:41', NULL),
(18, 'Internal Medicine', '2023-11-21 05:58:08', NULL),
(19, 'Psychology', '2023-11-21 05:58:23', NULL),
(20, 'Nursing Services', '2023-11-21 06:04:25', NULL),
(21, 'nurse', '2023-11-26 06:24:07', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `password_reset`
--

CREATE TABLE `password_reset` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `reset_token_hash` varchar(64) DEFAULT NULL,
  `reset_token_expires_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tblcontactus`
--

CREATE TABLE `tblcontactus` (
  `id` int(11) NOT NULL,
  `fullname` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `contactno` bigint(12) DEFAULT NULL,
  `message` mediumtext DEFAULT NULL,
  `PostingDate` timestamp NULL DEFAULT current_timestamp(),
  `AdminRemark` mediumtext DEFAULT NULL,
  `LastupdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp(),
  `IsRead` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblcontactus`
--

INSERT INTO `tblcontactus` (`id`, `fullname`, `email`, `contactno`, `message`, `PostingDate`, `AdminRemark`, `LastupdationDate`, `IsRead`) VALUES
(6, 'angelica baracol', 'abaracol.k11938992@umak.edu.ph', 9282690953, ' Hi po', '2023-11-12 06:17:47', 'Hello', '2023-11-12 06:18:38', 1),
(8, 'Angelica Baracol', 'abaracol.k11938992@umak.edu.ph', 9282690953, 'hi po', '2023-11-19 13:12:29', 'hello', '2023-11-19 13:36:01', 1),
(9, 'Angelica Baracol', 'abaracol.k11938992@umak.edu.ph', 9282690953, 'are you ook?', '2023-11-19 13:38:00', 'im not okay', '2023-11-21 02:39:08', 1),
(10, 'Angelica Baracol', 'abaracol.k11938992@umak.edu.ph', 9282690953, 'hi', '2023-11-25 05:02:26', 'hello', '2023-11-25 05:02:54', 1),
(11, 'Angelica Baracol', 'baracolangelica436@gmail.com', 9282690953, 'hihhh', '2023-11-26 12:39:04', 'ok', '2023-11-26 12:46:40', 1),
(12, 'ange baracol', 'angebaracol@gmail.com', 9282690953, 'ghijk\r\n', '2023-11-26 12:39:24', NULL, NULL, NULL),
(13, 'Denise Mallorca', 'dmallorca.k11939061@umak.edu.ph', 9732372732, 'hi', '2023-11-30 02:02:03', 'hello', '2023-11-30 02:02:36', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tblmedicalhistory`
--

CREATE TABLE `tblmedicalhistory` (
  `ID` int(10) NOT NULL,
  `PatientID` int(10) DEFAULT NULL,
  `DoctorName` varchar(255) DEFAULT NULL,
  `BloodPressure` varchar(200) DEFAULT NULL,
  `BloodSugar` varchar(200) NOT NULL,
  `Weight` varchar(100) DEFAULT NULL,
  `Temperature` varchar(200) DEFAULT NULL,
  `MedicalPres` mediumtext DEFAULT NULL,
  `Diagnosis` text DEFAULT NULL,
  `Symptoms` text DEFAULT NULL,
  `CreationDate` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblmedicalhistory`
--

INSERT INTO `tblmedicalhistory` (`ID`, `PatientID`, `DoctorName`, `BloodPressure`, `BloodSugar`, `Weight`, `Temperature`, `MedicalPres`, `Diagnosis`, `Symptoms`, `CreationDate`) VALUES
(70, 20, 'Melvin Tolentino', '90/100', '170', '50kg', '39', 'awts', '1 day', 'sipon', '2023-11-25 23:06:30'),
(71, 20, 'Melvin Tolentino', '90/100', '170', '50kg', '39', 'biogesisc', 'kahapon', 'sakit ulo', '2023-11-25 23:06:52'),
(72, 20, 'Melvin Tolentino', '90/100', '170', '50kg', '39', 'thank you', 'ohhh ', 'salamat\r\n', '2023-11-25 23:08:53'),
(73, 18, 'Melvin Tolentino', '90/100', '170', '50kg', '39', 'biogesic', 'check', 'sipon', '2023-11-25 23:11:13'),
(74, NULL, 'Melvin Tolentino', '90/100', '170', '50kg', '39', 'biogesic', 'paa', 'none', '2023-11-25 23:54:11'),
(75, 21, 'Melvin Tolentino', '90/100', '170', '50kg', '39', 'yon', 'ha', 'hsah', '2023-11-25 23:54:50'),
(76, 19, 'Melvin Tolentino', '90/100', '170', '50kg', '39', 'tonnight', 'ewn', 'secret', '2023-11-25 23:55:16'),
(77, 14, 'Melvin Tolentino', '90/100', '170', '50kg', '39', 'idk', 'secret', 'sipon', '2023-11-25 23:58:56'),
(78, 13, 'Melvin Tolentino', '90/100', '170', '50kg', '39', 'highblood', 'bukas', 'sipon', '2023-11-26 05:49:02'),
(79, 22, 'Angela Maria Baracol', '90/100', '170', '50kg', '39', 'biogesic', 'idk ', 'none ', '2023-11-30 18:17:57');

-- --------------------------------------------------------

--
-- Table structure for table `tblpatient`
--

CREATE TABLE `tblpatient` (
  `ID` int(10) NOT NULL,
  `Docid` int(10) DEFAULT NULL,
  `PatientName` varchar(200) DEFAULT NULL,
  `PatientContno` bigint(10) DEFAULT NULL,
  `PatientEmail` varchar(200) DEFAULT NULL,
  `PatientGender` varchar(50) DEFAULT NULL,
  `PatientAdd` mediumtext DEFAULT NULL,
  `PatientAge` int(10) DEFAULT NULL,
  `PatientMedhis` mediumtext DEFAULT NULL,
  `CreationDate` timestamp NULL DEFAULT current_timestamp(),
  `UpdationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `tblpatient`
--

INSERT INTO `tblpatient` (`ID`, `Docid`, `PatientName`, `PatientContno`, `PatientEmail`, `PatientGender`, `PatientAdd`, `PatientAge`, `PatientMedhis`, `CreationDate`, `UpdationDate`) VALUES
(11, 12, 'Denise Mallorca', 961188237, 'dmallorca.k11939061@umak.edu.ph', 'Male', '53 D Edsa St. Brgy. Bangkal', 20, 'fever', '2023-11-14 06:07:34', '2023-11-14 06:07:49'),
(12, 12, 'Nicole Bibera', 966628907, 'nbibera.k11936492@umak.edu.ph', 'female', '2996 H. Santos St. Carmona', 20, 'None', '2023-11-14 06:24:44', NULL),
(13, 12, 'Ari Apug', 12312, 'ariben.apugan@umak.edu.ph', 'Male', 'makati na taguig', 20, 'Fracture 1980, covid 2019', '2023-11-21 05:47:07', '2023-11-21 05:54:07'),
(14, 12, 'Angelica Baracol', 928269053, 'angebaracol@gmail.com', 'female', '1233 california st. manila', 30, 'none\r\n', '2023-11-22 10:55:28', NULL),
(16, 12, 'Denise Marie', 918212817, 'denisemallorca@gmail.com', 'female', '53 D Edsa St. Brgy. Bangkal', 18, 'none', '2023-11-23 05:00:45', NULL),
(17, 45, 'Angelica Tabaog Baracol', 928269053, 'baracssangel@gmail.com', 'Male', '4333 tinio st. bangkal makati', 30, 'none\r\n', '2023-11-25 05:18:48', '2023-11-25 05:19:16'),
(19, 20, 'Angelica Baracol', 928269053, 'abaracol.k11938992@umak.edu.ph', 'female', '4333 tinio st. bangkal makati', 30, 'none', '2023-11-25 07:57:02', NULL),
(20, 20, 'Angelica Baracol', 928269053, 'abaracol.k11938992@umak.edu.ph', 'female', '4333 tinio st. bangkal makati', 30, 'none', '2023-11-25 08:00:55', NULL),
(21, 20, 'Angelica Baracol', 928269053, 'abaracol.k11938992@umak.edu.ph', 'Male', '4333 tinio st. bangkal makati', 30, 'none', '2023-11-26 06:53:57', '2023-11-26 06:54:29');

-- --------------------------------------------------------

--
-- Table structure for table `userlog`
--

CREATE TABLE `userlog` (
  `id` int(11) NOT NULL,
  `uid` int(11) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `userip` binary(16) DEFAULT NULL,
  `loginTime` timestamp NULL DEFAULT current_timestamp(),
  `logout` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `userlog`
--

INSERT INTO `userlog` (`id`, `uid`, `username`, `userip`, `loginTime`, `logout`, `status`) VALUES
(154, 45, 'abaracol.k11938992@umak.edu.ph', 0x3a3a3100000000000000000000000000, '2023-11-26 14:30:01', '26-11-2023 08:01:01 PM', 1),
(155, 45, 'abaracol.k11938992@umak.edu.ph', 0x3a3a3100000000000000000000000000, '2023-11-26 14:40:48', '26-11-2023 08:11:18 PM', 1),
(156, 45, 'abaracol.k11938992@umak.edu.ph', 0x3a3a3100000000000000000000000000, '2023-11-26 14:41:45', '26-11-2023 08:14:05 PM', 1),
(157, 45, 'abaracol.k11938992@umak.edu.ph', 0x3a3a3100000000000000000000000000, '2023-11-26 14:47:32', '26-11-2023 08:17:37 PM', 1),
(158, 45, 'abaracol.k11938992@umak.edu.ph', 0x3a3a3100000000000000000000000000, '2023-11-28 09:12:39', '28-11-2023 02:45:55 PM', 1),
(159, 45, 'abaracol.k11938992@umak.edu.ph', 0x3a3a3100000000000000000000000000, '2023-11-28 09:17:31', '28-11-2023 02:49:30 PM', 1),
(160, 45, 'abaracol.k11938992@umak.edu.ph', 0x3a3a3100000000000000000000000000, '2023-11-29 06:49:56', '29-11-2023 12:26:49 PM', 1),
(161, 45, 'abaracol.k11938992@umak.edu.ph', 0x3a3a3100000000000000000000000000, '2023-11-29 07:07:10', '29-11-2023 12:39:43 PM', 1),
(162, 45, 'abaracol.k11938992@umak.edu.ph', 0x3a3a3100000000000000000000000000, '2023-11-29 07:10:34', '29-11-2023 12:41:57 PM', 1),
(163, NULL, 'dmallorca.k11939061@umak.edu.ph', 0x3a3a3100000000000000000000000000, '2023-11-30 01:49:54', NULL, 0),
(164, NULL, 'dmallorca.k11939061@umak.edu.ph', 0x3a3a3100000000000000000000000000, '2023-11-30 01:50:17', NULL, 0),
(165, NULL, 'dmallorca.k11939061@umak.edu.ph', 0x3a3a3100000000000000000000000000, '2023-11-30 01:53:00', NULL, 0),
(166, 44, 'dmallorca.k11939061@umak.edu.ph', 0x3a3a3100000000000000000000000000, '2023-11-30 01:53:09', '30-11-2023 07:25:03 AM', 1),
(167, NULL, 'dmallorca.k11939061@umak.edu.ph', 0x3a3a3100000000000000000000000000, '2023-11-30 02:15:55', NULL, 0),
(168, 47, 'dmallorca.k11939061@umak.edu.ph', 0x3a3a3100000000000000000000000000, '2023-11-30 02:16:42', NULL, 1),
(169, 45, 'abaracol.k11938992@umak.edu.ph', 0x3a3a3100000000000000000000000000, '2023-12-01 01:01:56', '01-12-2023 06:34:15 AM', 1),
(170, 45, 'abaracol.k11938992@umak.edu.ph', 0x3a3a3100000000000000000000000000, '2023-12-01 01:05:44', '01-12-2023 06:36:32 AM', 1),
(171, NULL, 'abaracol.k11938992@umak.edu.ph', 0x3a3a3100000000000000000000000000, '2023-12-01 02:01:59', NULL, 0),
(172, 48, 'abaracol.k11938992@umak.edu.ph', 0x3a3a3100000000000000000000000000, '2023-12-01 02:04:02', '01-12-2023 07:35:06 AM', 1),
(173, 48, 'abaracol.k11938992@umak.edu.ph', 0x3a3a3100000000000000000000000000, '2023-12-01 02:06:14', '01-12-2023 07:36:34 AM', 1),
(174, NULL, 'abaracol.k11938992@umak.edu.ph', 0x3a3a3100000000000000000000000000, '2023-12-01 02:09:29', NULL, 0),
(175, 48, 'abaracol.k11938992@umak.edu.ph', 0x3a3a3100000000000000000000000000, '2023-12-01 02:10:38', '01-12-2023 07:42:05 AM', 1),
(176, 48, 'abaracol.k11938992@umak.edu.ph', 0x3a3a3100000000000000000000000000, '2023-12-01 02:12:38', '01-12-2023 07:43:42 AM', 1),
(177, 48, 'abaracol.k11938992@umak.edu.ph', 0x3a3a3100000000000000000000000000, '2023-12-01 02:36:38', '01-12-2023 08:48:44 AM', 1);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fullName` varchar(255) DEFAULT NULL,
  `address` longtext DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `gender` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `otp` varchar(10) NOT NULL,
  `activation_code` varchar(10) NOT NULL,
  `status` varchar(255) NOT NULL,
  `regDate` timestamp NULL DEFAULT current_timestamp(),
  `updationDate` timestamp NULL DEFAULT NULL ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullName`, `address`, `city`, `gender`, `email`, `password`, `otp`, `activation_code`, `status`, `regDate`, `updationDate`) VALUES
(41, 'Ari Apug', 'makati na taguig', 'Wee', 'male', 'ariben.apugan@umak.edu.ph', '83422503bcfc01d303030e8a7cc80efc', '', '', '1', '2023-11-21 05:35:25', '2023-11-21 05:35:58'),
(47, 'Denise Mallorca', '53 D Edsa St. Brgy. Bangkal', 'makati', 'female', 'dmallorca.k11939061@umak.edu.ph', '5d7934930ab3c59febe7bb238f348c90', '592858', '', 'status', '2023-11-30 02:16:18', NULL),
(48, 'Angelica Baracol', '4333 tinio st. bangkal makati', 'Makati', 'female', 'abaracol.k11938992@umak.edu.ph', 'e807f1fcf82d132f9bb018ca6738a19f', '', '', '1', '2023-12-01 02:02:42', '2023-12-01 02:03:54');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `audit_log`
--
ALTER TABLE `audit_log`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctors`
--
ALTER TABLE `doctors`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctorslog`
--
ALTER TABLE `doctorslog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctorspecilization`
--
ALTER TABLE `doctorspecilization`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_reset`
--
ALTER TABLE `password_reset`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `reset_token_hash` (`reset_token_hash`);

--
-- Indexes for table `tblcontactus`
--
ALTER TABLE `tblcontactus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tblmedicalhistory`
--
ALTER TABLE `tblmedicalhistory`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `tblpatient`
--
ALTER TABLE `tblpatient`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `userlog`
--
ALTER TABLE `userlog`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=67;

--
-- AUTO_INCREMENT for table `audit_log`
--
ALTER TABLE `audit_log`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `doctors`
--
ALTER TABLE `doctors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `doctorslog`
--
ALTER TABLE `doctorslog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=145;

--
-- AUTO_INCREMENT for table `doctorspecilization`
--
ALTER TABLE `doctorspecilization`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `password_reset`
--
ALTER TABLE `password_reset`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tblcontactus`
--
ALTER TABLE `tblcontactus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tblmedicalhistory`
--
ALTER TABLE `tblmedicalhistory`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;

--
-- AUTO_INCREMENT for table `tblpatient`
--
ALTER TABLE `tblpatient`
  MODIFY `ID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `userlog`
--
ALTER TABLE `userlog`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=178;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
