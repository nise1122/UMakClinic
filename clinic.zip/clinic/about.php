<!DOCTYPE HTML>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes, minimum-scale=1.0, maximum-scale=10.0">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta content="" name="description" />
    <meta content="" name="author" />
    <title>Medical and Dental Clinic</title>
    <link rel="stylesheet" href="css/navstyle.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="about.css">
    <link rel="icon" href="umaklogo.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css"
        integrity="sha384-wvfXpqpZZVQGK6TAh5PVlK3uPfNfexUEFpy+JcPXdA0R+5dFZtFm4nFj1cO5N2+7" crossorigin="anonymous">
    <link href='https://fonts.googleapis.com/css?family=Ropa+Sans' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="css/responsiveslides.css">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css">

    <!-- Add these lines to include jQuery and Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

<style>

    .image-slider {
        max-width: 550px; /* Adjusted maximum width for better responsiveness */
        margin: 0 auto;
        margin-top: 300px; /* Adjusted top margin for better positioning */
        text-align: center;
        border: 3px solid #007bff;
        border-radius: 10px;
        position: relative;
        z-index: 15;
        overflow: hidden; /* Added overflow: hidden to prevent horizontal scroll on small screens */
    }

    h2 {
        margin-top: -540px; /* Adjusted margin-top for the "OUR STAFF" section */
        text-align: center;
    }

   @media only screen 
  and (min-device-width: 375px) 
  and (max-device-width: 768px) 
  and (-webkit-min-device-pixel-ratio: 2) {
        .image-slider {
            width:70%;
            margin-top: 450px; /* Adjusted top margin for small screens */
        }

        .service-columns {
            width: 100%;
            display: flex;
            flex-direction: column;
            align-items: center;
            
        }

        .image-slider img {
            max-width: 100%; /* Ensuring the image inside the slider is responsive */
        }

        .service-item {
            flex-basis: 100%;
            margin-bottom: 20px;
        }

        h2 {
            margin-top: -20px; /* Adjusted margin-top for the "OUR STAFF" section on mobile */
        }
        
        .service-columns {
          margin-top:5px;
          display: flex;
          justify-content: space-around;
          flex-wrap: wrap;
      }
      
          .logo-container {
    display: flex;
    align-items: center;
}

.logo-container img {
    max-height: 50px;
    margin-right: 5px; /* Adjust the margin as needed */
}

.text-container {
    display: flex;
    flex-direction: column;
    justify-content: center;
}

.navbar-logo {
    font-size: 13.5px; /* Adjust the font size as needed */
}
    }
</style>
<body>

    <!-- Main content -->
    <main>
        <!--start-header-->
        <div class="header">
            <div class="wrap">
                <!--start-logo-->
                <nav class="navbar navbar-expand-custom navbar-mainbg fixed-top">
                    <div class="logo-container">
                        <img src="logomed.png" style="max-height: 70px; margin-right: 1px;">
                        <div class="text-container">
                            <span class="navbar-brand navbar-logo clinic-name">MEDICAL AND DENTAL CLINIC</span>
                        </div>
                    </div>

                    <button class="navbar-toggler" type="button" aria-controls="navbarSupportedContent"
                        aria-expanded="false" aria-label="Toggle navigation">
                        <i class="fas fa-bars "></i>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul class="navbar-nav ml-auto">
                            <li class="nav-item">
                                <a class="nav-link" href="index.php"><i class="fas fa-home"></i>HOME</a>
                            </li>
                            <li class="nav-item active">
                                <a class="nav-link" href="about.php"><i class="far fa-address-book"></i>ABOUT</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="contact.php"><i class="far fa-envelope"></i>CONTACT</a>
                            </li>
                        </ul>
                    </div>
                </nav>
                <!--end-top-nav-->
            </div>
        </div>

        <!-- Parallax Image Slider -->
        <div class="parallax">
            <div class="clear"></div>
            <!--start-image-slider---->
            
                <div class="image-slider">
                <img src="images/about-slide.gif" alt="About Slide">
            </div>
            <!--End-image-slider---->
        </div>
        

         <!-- Services Section -->
         <section id="services">
            <div class="service-columns">
                <div class="service-item">
                    <div class="icon">
                        <img src="images/logomed.png" alt="Icon">
                        <p>MEDICAL SERVICES</p>
                    </div>
                    <h4>Physical examination of new students</h4>
                    <h4>Annual Physical exam for employees</h4>
                    <h4>medical consultation</h4>
                    <h4>first aid for medical emergencies</h4>
                    <h4>blood pressure monitoring </h4>
                    <h4>prescription and issuance of medicines </h4>
                    <h4>issuance of referrals and medical certificates </h4>
                    <h4>hospital / home visit </h4>
                    <h4>health seminars </h4>
                    <h4>blood request assistance </h4>
                </div>

                    <div class="service-item">
                    <div class="icon">
                        <img src="images/logomed.png" alt="Icon">
                        <p>DENTAL SERVICES</p>
                    </div>
                    <h4>dental consultation</h4>
                    <h4>Annual dental exam of employees</h4>
                    <h4>oral examination of new students</h4>
                    <h4>prescription and issuance of medicine</h4>
                    <h4>issuance of dental referrals and dental certificates </h4>
                    <h4>simple tooth extraction </h4>
                    <h4>tooth restoration </h4>
                    <h4>gum treatment </h4>
                    <h4>attend to oral emergency cases </h4>
                </div>
</div>
</div>
</section>

<div class="parallax"></div>
     <!-- Staff Section -->
     <h2>OUR STAFF</h2>

<table>
    <thead>
        <tr>
            <th>Name</th>
            <th>Role</th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>ALAN ANGELO N. RAYMUNDO, MD</td>
            <td>Section Head, Medical Services</td>
        </tr>
        <tr>
            <td>MARIA LINDA H. RAMIREZ, MD</td>
            <td>Department Head</td>
        </tr>    
        <tr>
            <td>ROWENA N. ALVAREZ, RN</td>
            <td>Head Nurse</td>
        </tr>  
        <tr>
            <td>JOHN JAMESON G. CRUZ, RN</td>
            <td>Nurse</td>
        </tr>  
        <tr>
            <td>ARI BEN P. APUGAN, RN</td>
            <td>Nurse</td>
        </tr>  
        <tr>
            <td>MARICRIS C. NACINOPA, RN</td>
            <td>Nurse</td>
        </tr>  
        <tr>
            <td>CELY P. MOLINES, DMD</td>
            <td>Section Head, Dental Services</td>
        </tr>  
        <tr>
            <td>VANESSA C. SALIRE, DMD</td>
            <td>Dentist</td>
        </tr>  
    
    </tbody>
</table>


<!-- Table for Forms and Downloads -->
 <div class="downloads-table">
        <table>
            <tr>
                <th>File</th>
                <th>Link</th>
            </tr>
            <tr>
                <td>Medical and Dental Form (Please print back to back in long bond paper)</td>
                <td>
                    <a href="MEDICAL FORM STUDENT 2023 FILLABLE FORM.pdf" target="_blank">Download | PDF</h1>
                </td>
            </tr>
            <tr>
                <td>Medical Referral Slip for First Year Students / Grade 11 Students</td>
                <td>
                    <a href="REFERRAL SLIP for Grade 11 and 1st Year students.pdf" target="_blank">View | PDF</a>
                </td>
            </tr>
            <tr>
                <td>Medical Referral Slip for Nursing, Pharmacy and Rad Tech First Year Students</a>
                <td>
                    <a href="Nursing pharma radtech 1st yr.pdf" target="_blank">View | PDF</a>
                </td>
            </tr>
        </table>
    </div>
    </div>

    </main>

    <?php include('footer1.html'); ?>

    <!-- Include scripts just before closing </body> tag -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.8.1/slick.min.js"></script>
    <script src="js/responsiveslides.min.js"></script>
    <script src="js/navbar.js"></script>

    <script>
    $(document).ready(function () {
        // Slideshow 1
        $("#slider1").responsiveSlides({
            maxwidth: 1600,
            speed: 10,
            auto: true, // Set to true to enable auto-swipe
            timeout: 5000 // Set the time between slides in milliseconds (5 seconds in this example)
        });
    });
</script>


</body>

</html>
