
<!DOCTYPE HTML>
<html>
<head>
 <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=yes, minimum-scale=1.0, maximum-scale=10.0">
		<meta name="apple-mobile-web-app-capable" content="yes">
		<meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta content="" name="description" />
    <meta content="" name="author" />
    <title>Medical and Dental Clinic</title>
  
    <link rel="stylesheet" href="css/navstyle.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="icon" href="umaklogo.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css"
        integrity="sha384-wvfXpqpZZVQGK6TAh5PVlK3uPfNfexUEFpy+JcPXdA0R+5dFZtFm4nFj1cO5N2+7" crossorigin="anonymous">
    <link href='http://fonts.googleapis.com/css?family=Ropa+Sans' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="css/responsiveslides.css">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" type="text/css">

    <!-- Add these lines to include jQuery and Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.3.1.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>

<style>
    
    .parallax {
    position: relative;
    min-height: 500px;
    overflow: hidden;
}

.parallax:before {
    content: "";
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-image: url("images/slider-image3.jpg");
    background-attachment: fixed;
    background-position: center;
    background-repeat: no-repeat;
    background-size: cover;
    filter: brightness(0.4);
    z-index: -1; 
}

.announcement {
    background: linear-gradient(135deg, #001f3f, #009688, #0056b3, #003366); 
    color: white;
    text-align: center;
    padding: 5px;
    margin-top: 200px; 
    width: 45%;
    border-radius: 5px;
    position: absolute;
    left: 50%;
    transform: translateX(-50%);
}

.announcement a {
    color: #fff; 
    text-decoration: underline;
}

.announcement a:hover {
    color: #ebebf4; 
    text-decoration: underline;
}

.text-container {
    flex-grow: 1;
    display: flex;
    flex-direction: column;
    align-items: center;
}



.subtitle-container {
    display: flex;
    flex-direction: column;
    margin-top: -80px; 
    text-align: center;
    position:fixed;
}

.about-container {
width: 100%;
    margin-top:-200px;
background-color: #ebebf4;
padding: 10px;
display: flex;
align-items: center;
justify-content: center;
text-align: center;
min-height: 400px; 
margin-right:10px;
}
.about-container h2 {
color: #337CCF;
font-size: 40px;
margin-bottom: 5px; 
}


.clinic-info {
margin-bottom: 5px; 
}
.clinic-name2 {
font-size: 25px; 
margin-right: 5px; 
}

.university1 {
font-size: 18px; 
color: rgba(51, 124, 207, 0.8);
font-weight: bold; 
}

#mission-vision {
    display: flex;
    justify-content: space-around;
    align-items: center;
    padding: 70px 0;
    position: relative; 
    z-index: 1; 
    transition: margin-top 1s ease;
}

.mission-container,
.vision-container {
    text-align: center;
    padding: 20px;
    background: transparent;
}

.mission-content,
.vision-content {
    max-width: 450px;
    margin: 20px auto;
    margin-top: 40px;
}

.mission-content h2,
.vision-content h2 {
    font-size: 24px;
    color: white;
}

.mission-content p,
.vision-content p {
    font-size: 16px;
    color: white;
}

.listview_1_of_3 {

    display: flex;
    flex-direction: row;
    justify-content: center;
    align-items:center;
    position: relative;
    top: -130px;
    left: 70%;
    transform: translateX(-70%);
    z-index: 999;
}

.listview_1_of_3 .icon {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 300px;
    height: 170px;
    border-radius: 7px;
    position: relative;
    cursor: pointer;
    transition: background-color 0.3s ease;
    margin-right: 10px; /* Reduced margin for mobile */
}

.listview_1_of_3 .icon img {
    max-width: 80%;
    height: auto;
    margin-bottom: 20px;
    margin-left: 10px;
    transition: transform 0.3s ease; 
}

.listview_1_of_3 .icon:hover img {
    transform: scale(1.3);
}

.listview_1_of_3 .texts {
    position: absolute;
    top: 120%;
    left: 45%;
    transform: translate(-50%, -50%);
    opacity: 0;
    transition: opacity 0.3s ease-in-out;
    font-size:9px;
}

.listview_1_of_3 .image-container:hover .texts {
    opacity: 1;
}
    
.listview_1_of_3 .texts p {
    font-size: 9px; /* Adjust font size as needed */
    margin: 0;
}
.listview_1_of_3 .texts h3 {
    font-size: 19px !important;
    position: relative; 
    color: rgb(16, 0, 75);
}


.core-values-container {
text-align: center;
background: white;
height:20%;
}

.core-values-list {
display: flex;
justify-content: space-around;
margin-top: 20px;
}

.core-value {
width: 30%; 
}

.core-value img {
max-width: 100%;
height: 30px;
margin-bottom: 10px;
}

.core-value p {
font-size: 18px;
font-weight: bold;
}
#services {
padding: 80px;
align-items: center;

}
.services-content {
text-align: center;
padding: 20px;
border-radius: 10px;
transition: margin-top 1s ease;
max-width: 1200px; 
width: 100%;
display: flex;
justify-content: space-around;
align-items: flex-start;
}

.service {
flex: 1;
text-align: center;
margin: 20px;
}

.service h3 {
font-size: 24px;
color: white;
}

.service p {
font-size: 16px;
color: white;
}

#services.transition-effect {
margin-top: 20px;
}
#prescriptions {
background-color: #ebebf4;
padding: 50px 0; 
color: black;
border-top: 2px solid white; 
    border-bottom: 2px solid white; 
}

.prescriptions-content {
text-align: center;
padding: 20px;
border-radius: 10px;
transition: margin-top 1s ease;
display: flex;
flex-direction: row;
align-items: flex-start;
justify-content: space-around;
}

.prescription h2 {
font-size: 25px;
font-weight: bold;
color: black;
margin-bottom: 20px;
}

.prescription {
flex: 1;
text-align: center;
margin: 20px;
}

.prescription p {
font-size: 16px;
color: black;
}

#prescriptions.transition-effect {
margin-top: 20px;
}
#chat-section12 {
width: 380px;
margin: 40px;
padding: 20px;
background-color: #f9f9f9;
box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
border-radius: 8px;
display: flex;
flex-direction: column;
position: fixed;
bottom: 07px;
right: 50px;
display: none;
z-index: 10000;
}

#chat-box {
overflow-y: scroll;
max-height: 300px;
border: 1px solid #ddd;
padding: 10px;
margin-bottom: 10px;
border-radius: 5px;
}

#user-input {
width: 100%;
padding: 10px;
margin: 0;
box-sizing: border-box;
border: 1px solid #eddcdc;
border-radius: 5px;
margin-top: 15px;
}

#send-button {
width: 100%;
padding: 10px;
background-color: #4267b2;
color: #fff;
border: none;
cursor: pointer;
border-radius: 5px;
margin-top: 10px;
}

.choices {
overflow-x: auto;
white-space: nowrap;
margin-bottom: 0px;
}

.choice {
display: inline-block;
background-color: #4267b2;
color: #fff;
padding: 10px;
margin-right: 5px;
border: none;
cursor: pointer;
border-radius: 5px;
}

.choice:hover {
background-color: #314c86;
}

.response-message {
max-width: 50%;
word-wrap: break-word;
}

#chatbot-icon {
position: fixed;
bottom: 15px;
right: 15px;
background-image: url('chat.gif');
background-size: cover;
background-position: center;
width: 60px;
height: 60px;
border-radius: 60%;
border: none;
cursor: pointer;
display: flex;
align-items: center;
justify-content: center;
z-index: 10000;
transition: transform 0.3s ease-in-out;
}
#chatbot-icon:hover {
transform: scale(1.2); 
}
.hide-element {
    display: none;
}
/* Mobile styles */

@media only screen 
  and (min-device-width: 375px) 
  and (max-device-width: 768px) 
  and (-webkit-min-device-pixel-ratio: 2){

    
 .listview_1_of_3 {
        display: flex;
        flex-direction: row; /* Change to row */
        justify-content: center;
        align-items: center;
        position: relative;
        margin-top: 10px;
        margin-left: 0;
        padding:50px;
        margin-top:3px;
    }

    .listview_1_of_3 .icon {
    
        align-items: center;
        margin-left: 10px;
        
    }

    
     #chat-section12 {
        width: 80%;
        max-width: none;
        margin: 10px;
        bottom:50px;
    }

    #chatbot-icon {
        bottom: 7px; 
        right: 30px; 
    }
    
    .link-boxes {
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
    }

    .box {
        width: 100%;
        margin-bottom: 20px;
    }

    .box input-box {
        margin-bottom: 0;
    }
    .services-content,
.prescriptions-content {
    flex-direction: column; /* Change to column layout for smaller screens */
    align-items: center; /* Center items in the column */
}

/* Adjust styles for service */
.service {
    flex: 1;
    text-align: left;
    margin: 10px; /* Adjust margin as needed */
}

.service h3 {
    font-size: 24px;
    font-weight: bold; /* Correct the property name */
    color: white;
}

/* Adjust styles for prescription */
.prescription {
    flex: 1;
    text-align: left;
    margin: 20px; /* Adjust margin as needed */
}

.prescription h2 {
    font-size: 25px;
    font-weight: bold;
    color: black;
    margin-bottom: 20px;
    margin-left:75px
}

.prescription p {
    font-size: 16px;
    color: black;
    margin-left:75px
}
.announcement {
        width: 90%; /* Adjust width for smaller screens */
        margin-top: 250px; /* Adjust margin-top for smaller screens */
    }
    .listview_1_of_3 .icon img {
    max-width: 200px;
    height: auto;
    margin-bottom: 20px;
    margin-left: 10px;
    transition: transform 0.3s ease; 
    margin-top:-90px;
}
    
.listview_1_of_3 .texts {
    margin-top:0px;
    opacity:1;
    font-size: 67px !important;/* Adjust font size as needed */
    margin: 0;
} 

.listview_1_of_3 .texts h3 {
    margin-left:5px;
    margin-top:-100px;
    font-size:14.5px !important;
    position: relative; 
    color: rgb(16, 0, 75);
    text-decoration: underline;
}
.about-container {
margin-top:-280px;
height:300px;
}
.about-container h2 {
color: #337CCF;
font-size: 40px;
margin-top: 80px; 
} 
    #mission-vision {
        flex-direction: column;
        align-items: center;
    }

    .mission-content,
    .vision-content {
        max-width: 100%; /* Adjust the width for smaller screens */
        margin-top: 20px; /* Adjust the margin for spacing */
    }
    
    .logo-container {
    display: flex;
    align-items: center;
}

.logo-container img {
    max-height: 50px;
    margin-right: 5px; /* Adjust the margin as needed */
}

.text-container {
    display: flex;
    flex-direction: column;
    justify-content: center;
}

.navbar-logo {
    font-size: 13.5px; /* Adjust the font size as needed */
}

}


</style>
<body>


    <!-- Navigation Section -->
   <!--start-header-->
   <div class="header">
        <div class="wrap">
            <!--start-logo-->
            <nav class="navbar navbar-expand-custom navbar-mainbg fixed-top">
                <div class="logo-container">
                    <img src="logomed.png" style="max-height: 70px; margin-right: 1px;">
                    <div class="text-container">
                        <span class="navbar-brand navbar-logo clinic-name">MEDICAL AND DENTAL CLINIC</span>
                    </div>
                </div>
  

                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
                    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fas fa-bars text-black"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item active">
                                <a class="nav-link" href="index.php"><i class="fas fa-home"></i>HOME</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="about.php"><i class="far fa-address-book"></i>ABOUT</a>
                            </li>
                           
                            <li class="nav-item ">
                                <a class="nav-link" href="contact.php"><i class="far fa-envelope"></i>CONTACT</a>
                            </li>
    </div>

                </nav>
				<!--end-top-nav-->
			</div>
			<!--end-header-->

        <!--end-header-->
        <div class="parallax">
        <div class="announcement">
            <p><a href="hms/user-login.php">Welcome to the University of Makati Medical and Dental Clinic Virtual Campus! Ready to book your appointment? Click here.</a></p>
        </div>
    </div>


    <div class="clear"> 
		    <div class="content-grids">
		    	<div class="wrap">
		    	<div class="section group">
                             
                               <div class="listview_1_of_3">
<a href="hms/doctor/" class="icon hide-element">
        <div class="image-container">
            <img src="images/patient.gif" alt="Doctors Login">
            <div class="texts">
                <h3>DOCTORS LOGIN</h3>
            </div>
        </div>
    </a>

<a href="hms/admin" class="icon hide-element">
        <div class="image-container">
            <img src="images/admin.gif" alt="Admin Login">
            <div class="texts">
                <h3>ADMIN LOGIN</h3>
            </div>
        </div>
    </a>
</div>



        <!--chatbot-->
        <button id="chatbot-icon" onclick="toggleChatbox()"></button>

<section id="chat-section12">
    <div id="chat-box"></div>

    <div class="choices">
        <button class="choice" onclick="sendChoice('Clinic Hours')">Clinic Hours</button>
        <button class="choice" onclick="sendChoice('Location')">Location</button>
        <button class="choice" onclick="sendChoice('Payment')">Payment</button>
        <button class="choice" onclick="sendChoice('Services')">Services</button>
        <button class="choice" onclick="sendChoice('Can patient outside UMak book an appointment here?')">Can patient outside UMak book an appointment here?</button>
        <button class="choice" onclick="sendChoice('How to Book an Appointment')">How to Book an Appointment</button>
    </div>

    <input type="text" id="user-input" placeholder="Type your message...">
    <button id="send-button" onclick="sendMessage()">Send</button>
</section>


        <!--About-->
        <div class="about-container">
            <div class="wrap">
                <h2>ABOUT</h2>
                <p class="clinic-info">
                    <span class="clinic-name2">MEDICAL AND DENTAL CLINIC</span>
                </p>
                <P> <span class="university1">UNIVERSITY OF MAKATI</span> </P>
                <p>
                    The Medical and Dental Clinic intends to provide basic healthcare for students and/or refer them to the specialist/primary health center if necessary. It provides first aid and triage for illnesses and injuries, direct services to students with special needs, and health counseling and education to students, staff, and parents.
                </p>
               
            </div>
        </div>
    </div>
    <div class="parallax">
            <!-- Mission and Vision Section -->
            <section id="mission-vision" class="mission-vision-section">
                <div class="mission-container">
                    <div class="mission-content">
                        <h2>MISSION</h2>
                        <p>With its commitment in service, the clinic shall provide the medical and dental needs of the University of Makati community by doing preventive medicine and treatment of illness.</p>
                    </div>
                </div>

                <div class="vision-container">
                    <div class="vision-content">
                        <h2>VISION</h2>
                        <p>For the University of Makati (UMAK) community to be healthy in mind and body through competent and quality medical care.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Core Values Section -->
<section id="core-values" class="core-values-section">
    <div class="core-values-container">
        <h2>Core Values</h2>
        <div class="core-values-list">
            <div class="core-value">
                <img src="images/core3.png" alt="Professionalism Logo">
                <p>Professionalism</p>
            </div>
            <div class="core-value">
                <img src="images/core2.png" alt="Integrity Logo">
                <p>Integrity</p>
            </div>
            <div class="core-value">
                <img src="images/core1.png" alt="Excellence Logo">
                <p>Excellence</p>
            </div>
        </div>
    </div>
</section>

<div class="parallax">
<!-- Services Section -->
<section id="services" class="services-section">
    <div class="services-content">
        <div class="service">
            <h3>Medical and Dental Services</h3>
            <p>Provide Free Medical and Dental Consultation & Services to Employees and Students.</p>
        </div>

        <div class="service">
            <h3>Health Awareness</h3>
            <p>Provide programs to promote health and prevent illness to Employees and Students.</p>
        </div>

        <div class="service">
            <h3>First Aid</h3>
            <p>Provide First Aid For Medical Emergencies.</p>
        </div>
    </div>
</section>

<!-- Prescriptions Section -->
<section id="prescriptions" class="prescriptions-section">
    <div class="prescriptions-content">
        <div class="prescription">
            <h2>Prescriptions</h2>
            <p>Prescription and Issuance of Medicines</p>
        </div>

        <div class="prescription">
            <h2>Implement Policies</h2>
            <p>Formulate and implement policies & procedures for the physical & mental health of employees and students.</p>
        </div>
    </div>
</section>  
</div>
</div>
<div class="parallax"></div>

<script>
    var isConnectingToLiveAgent = false;

    function sendMessage() {
        var userInput = document.getElementById('user-input');
        var chatBox = document.getElementById('chat-box');

        var userMessage = userInput.value.trim();
        if (userMessage !== '') {
            // Display user message
            chatBox.innerHTML += '<div style="text-align: right; margin-bottom: 5px;"><p style="background-color: #4267b2; color: #fff; padding: 10px; border-radius: 5px; display: inline-block;">' + userMessage + '</p></div>';
            // Clear input field
            userInput.value = '';

            // Simulate a chatbot response
            var botResponse = getBotResponse(userMessage);

            // Display chatbot response with the response-message class
            chatBox.innerHTML += '<div style="text-align: left; margin-bottom: 5px;"><p class="response-message" style="background-color: #ddd; color: #333; padding: 10px; border-radius: 5px; display: inline-block;">' + botResponse + '</p></div>';

            // If connecting to live agent, simulate a delay and then show a response
            if (isConnectingToLiveAgent) {
                setTimeout(function () {
                    chatBox.innerHTML += '<div style="text-align: left; margin-bottom: 5px;"><p class="response-message" style="background-color: #ddd; color: #333; padding: 10px; border-radius: 5px; display: inline-block;">You are now connected to a live agent.</p></div>';
                    isConnectingToLiveAgent = false;
                    // Scroll to the bottom of the chat box
                    chatBox.scrollTop = chatBox.scrollHeight;
                }, 2000); // Simulating a 2-second delay
            } else {
                // Scroll to the bottom of the chat box
                chatBox.scrollTop = chatBox.scrollHeight;
            }
        } else {
        // If the user input is empty, provide a default response
        var defaultResponse = "Please type your question.";
        chatBox.innerHTML += '<div style="text-align: left; margin-bottom: 5px;"><p class="response-message" style="background-color: #ddd; color: #333; padding: 10px; border-radius: 5px; display: inline-block;">' + defaultResponse + '</p></div>';
        // Scroll to the bottom of the chat box
        chatBox.scrollTop = chatBox.scrollHeight;
    }}

    function sendChoice(choice) {
        // Display user choice
        var chatBox = document.getElementById('chat-box');
        chatBox.innerHTML += '<div style="text-align: right; margin-bottom: 5px;"><p style="background-color: #4267b2; color: #fff; padding: 10px; border-radius: 5px; display: inline-block;">' + choice + '</p></div>';

        // Simulate a chatbot response based on the user's choice
        var botResponse = getBotResponse(choice);

        // Display chatbot response with the response-message class
        chatBox.innerHTML += '<div style="text-align: left; margin-bottom: 5px;"><p class="response-message" style="background-color: #ddd; color: #333; padding: 10px; border-radius: 5px; display: inline-block;">' + botResponse + '</p></div>';

        // Scroll to the bottom of the chat box
        chatBox.scrollTop = chatBox.scrollHeight;
    }

    function getBotResponse(userMessage) {
        // Replace this function with actual chatbot integration logic
        // For simplicity, using a simple response based on user input
        if (userMessage.toLowerCase().includes('clinic hours')) {
            return 'The UMak Medical and Dental Clinic is open every Mondays to Fridays, 8:00 A.M to 5:00 P.M';
        } else if (userMessage.toLowerCase().includes('location')) {
            return 'We are located in Ground Floor, Admin Bldg. of University of Makati.';
        } else if (userMessage.toLowerCase().includes('can patient outside umak book an appointment here?') || userMessage.toLowerCase().includes('umak students') || userMessage.toLowerCase().includes('outsiders')) {
            return 'No, we only accept patients that study or work inside University of Makati.';
        } else if (userMessage.toLowerCase().includes('payment')) {
            return 'UMak Medical and Dental Clinic is free of charge.';
        } else if (userMessage.toLowerCase().includes('can students have a check up here?')) {
            return 'Yes, if they are a student or worker in UMak they can avail the services that we offer here.';
        } else if (userMessage.toLowerCase().includes('how to book an appointment')) {
  return '<a href="hms/user-login.php">Login</a> to your Umak account first. <br> Then go to Book an Appointment and fill out the information needed. <br><br>If you still don\'t have an account, go to this page to <a href="hms/registration.php">Create Account</a>!';


        } else if (userMessage.toLowerCase().includes('services')) {
            return 'We offer free Medical Check-up and Dental Services';
        } else {
            return "I don't quite understand your question. Can I help you with something?";
        }
        
    }

 function toggleChatbox() {
        var chatbox = document.getElementById('chat-section12');
        var chatBox = document.getElementById('chat-box');

        if (chatbox.style.display === 'none' || chatbox.style.display === '') {
            // Display the welcome message when chatbox is opened
            chatBox.innerHTML += '<div style="text-align: left; margin-bottom: 5px;"><p class="response-message" style="background-color: #ddd; color: #333; padding: 10px; border-radius: 5px; display: inline-block;">Welcome to the University of Makati Medical and Dental Clinic Chatbot! How can I assist you today?</p></div>';
        }

        chatbox.style.display = (chatbox.style.display === 'none' || chatbox.style.display === '') ? 'flex' : 'none';

        // Scroll to the bottom of the chat box after toggling
        chatBox.scrollTop = chatBox.scrollHeight;
    }

    document.getElementById('user-input').addEventListener('keypress', function (event) {
        if (event.key === 'Enter') {
            sendMessage();
        }
    });
</script>
    
        </main>
<?php include ('footer1.html'); ?>
		<!-- start: MAIN JAVASCRIPTS -->
		<script src="vendor/jquery/jquery.min.js"></script>
		<script src="vendor/bootstrap/js/bootstrap.min.js"></script>
		<script src="vendor/modernizr/modernizr.js"></script>
		<script src="vendor/jquery-cookie/jquery.cookie.js"></script>
		<script src="vendor/perfect-scrollbar/perfect-scrollbar.min.js"></script>
		<script src="vendor/switchery/switchery.min.js"></script>
		<!-- end: MAIN JAVASCRIPTS -->
		<!-- start: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<script src="vendor/maskedinput/jquery.maskedinput.min.js"></script>
		<script src="vendor/bootstrap-touchspin/jquery.bootstrap-touchspin.min.js"></script>
		<script src="vendor/autosize/autosize.min.js"></script>
		<script src="vendor/selectFx/classie.js"></script>
		<script src="vendor/selectFx/selectFx.js"></script>
		<script src="vendor/select2/select2.min.js"></script>
		<script src="vendor/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
		<script src="vendor/bootstrap-timepicker/bootstrap-timepicker.min.js"></script>
		<!-- end: JAVASCRIPTS REQUIRED FOR THIS PAGE ONLY -->
		<!-- start: CLIP-TWO JAVASCRIPTS -->
		<script src="assets/js/main.js"></script>
		<!-- start: JavaScript Event Handlers for this page -->
		<script src="assets/js/form-elements.js"></script>
		<script>
			jQuery(document).ready(function() {
				Main.init();
				FormElements.init();
			});
		</script>
</body>
</html>
